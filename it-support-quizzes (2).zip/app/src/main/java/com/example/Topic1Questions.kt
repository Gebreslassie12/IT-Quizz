package com.example

object Topic1Questions {
    val questions = listOf(
        Question(
            id = 101,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which of the following best describes an <b>Information System</b>?",
            options = listOf(
                "Applying computer science principles to writing software code only.",
                "An organized system for collecting, organizing, storing and communicating information.",
                "The mechanical and physical parts that make up a computer network.",
                "The process of creating HTML and CSS websites."
            ),
            correctIndex = 1,
            explanationHtml = "An <b>Information System (IS)</b> is an organized combination of people, hardware, software, communications networks, and data resources that collects, transforms, and disseminates information in an organization."
        ),
        Question(
            id = 102,
            topic = "Information Systems and Their Applications",
            questionHtml = "What are the <b>five major components</b> of an Information System?",
            options = listOf(
                "HTML, CSS, JavaScript, PHP, SQL",
                "CPU, RAM, Hard Disk, Monitor, Keyboard",
                "Hardware, Software, Data, Procedures, People",
                "Input, Processing, Storage, Output, Feedback"
            ),
            correctIndex = 2,
            explanationHtml = "The five core components of any Information System are <b>Hardware</b> (devices), <b>Software</b> (programs), <b>Data</b> (raw facts), <b>Procedures</b> (rules/instructions), and <b>People</b> (users/designers)."
        ),
        Question(
            id = 103,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which type of Information System is designed to record daily, routine transactions like sales entries or payroll?",
            options = listOf(
                "Executive Information System (EIS)",
                "Decision Support System (DSS)",
                "Management Information System (MIS)",
                "Transaction Processing System (TPS)"
            ),
            correctIndex = 3,
            explanationHtml = "A <b>Transaction Processing System (TPS)</b> records and tracks the daily routine transactions necessary to conduct business (e.g., flight bookings, sales, deposits)."
        ),
        Question(
            id = 104,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which system helps middle managers with structured/semi-structured decisions by offering periodic, pre-defined reports?",
            options = listOf(
                "Management Information System (MIS)",
                "Transaction Processing System (TPS)",
                "Artificial Neural Networks (ANN)",
                "Office Automation System (OAS)"
            ),
            correctIndex = 0,
            explanationHtml = "<b>Management Information Systems (MIS)</b> summarize data from TPS to provide standard, routine reports to middle managers for monitoring and control."
        ),
        Question(
            id = 105,
            topic = "Information Systems and Their Applications",
            questionHtml = "A system that assists senior executives with unstructured, strategic decisions using external and internal summarized data is called:",
            options = listOf(
                "Transaction Processing System (TPS)",
                "Enterprise Resource Planning (ERP)",
                "Executive Information System (EIS)",
                "Database Management System (DBMS)"
            ),
            correctIndex = 2,
            explanationHtml = "<b>Executive Information Systems (EIS)</b> help senior-level executives analyze strategic issues and long-term trends, often using rich graphical dashboards."
        ),
        Question(
            id = 106,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the primary purpose of an <b>Enterprise Resource Planning (ERP)</b> system?",
            options = listOf(
                "To design web interfaces using modern markup languages.",
                "To integrate all functional departments of an entire business into a single cohesive system.",
                "To troubleshoot hard drive partitions and defragment files.",
                "To secure individual database servers using automated encryption keys."
            ),
            correctIndex = 1,
            explanationHtml = "An <b>ERP system</b> integrates all business processes (finance, HR, manufacturing, sales) into a unified database to ensure seamless flow of information across departments."
        ),
        Question(
            id = 107,
            topic = "Information Systems and Their Applications",
            questionHtml = "In the Systems Development Life Cycle (SDLC), during which phase is the database schema designed and UI layouts planned?",
            options = listOf(
                "System Planning",
                "System Analysis",
                "System Design",
                "System Implementation"
            ),
            correctIndex = 2,
            explanationHtml = "The <b>System Design</b> phase converts the requirements gathered during analysis into detailed blueprints, schemas, and structural designs."
        ),
        Question(
            id = 108,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the very first phase of the SDLC?",
            options = listOf(
                "Coding and Testing",
                "Feasibility Study & Planning",
                "Requirements Analysis",
                "System Maintenance"
            ),
            correctIndex = 1,
            explanationHtml = "The <b>Feasibility Study and Planning</b> phase explores whether a project is viable from cost, operational, and technical standpoints."
        ),
        Question(
            id = 109,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which SDLC implementation strategy involves running both the old and new systems simultaneously for a period of time?",
            options = listOf(
                "Direct Cutover",
                "Phased Implementation",
                "Pilot Implementation",
                "Parallel Implementation"
            ),
            correctIndex = 3,
            explanationHtml = "Under <b>Parallel Implementation</b>, both the old and new systems run together to verify the reliability of the new system before retiring the old one. It is the safest method."
        ),
        Question(
            id = 110,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which conversion type is highest risk because it involves shutting down the old system instantly and launching the new one?",
            options = listOf(
                "Direct Cutover",
                "Phased Conversion",
                "Pilot Conversion",
                "Parallel Conversion"
            ),
            correctIndex = 0,
            explanationHtml = "<b>Direct Cutover</b> (or Direct Conversion) is high-risk because there is no backup if the new system fails immediately upon launch."
        ),
        Question(
            id = 111,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is <b>Decision Support System (DSS)</b> primarily used for?",
            options = listOf(
                "Sending email notifications automatically to list subscribers.",
                "Assisting business managers with complex semi-structured or unstructured decisions.",
                "Hosting static web pages on local server instances.",
                "Managing backup copies of physical hardware configuration files."
            ),
            correctIndex = 1,
            explanationHtml = "<b>DSS</b> combines analytical models, specialized databases, and interactive user inputs to assist decision-makers with ambiguous problems."
        ),
        Question(
            id = 112,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which type of system is specifically designed to store and replicate the expertise of human professionals (e.g., medical specialists)?",
            options = listOf(
                "Office Information System (OIS)",
                "Expert System",
                "Transaction Processing System (TPS)",
                "Web Authoring Tool"
            ),
            correctIndex = 1,
            explanationHtml = "An <b>Expert System (ES)</b> uses a knowledge base and inference rules to mimic human reasoning and solve domain-specific expert challenges."
        ),
        Question(
            id = 113,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the primary role of <b>System Analysis</b> in the SDLC?",
            options = listOf(
                "Writing clean, compile-level program code.",
                "Reviewing exact business requirements and identifying user problems.",
                "Backing up active physical system databases.",
                "Buying peripheral hardware for network server setups."
            ),
            correctIndex = 1,
            explanationHtml = "<b>System Analysis</b> is the step of studying current systems and identifying precise goals and user needs of the proposed system."
        ),
        Question(
            id = 114,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which model of SDLC uses sequential, rigid phases where each step must be completed before the next begins?",
            options = listOf(
                "Spiral Model",
                "Waterfall Model",
                "Agile Model",
                "Prototyping Model"
            ),
            correctIndex = 1,
            explanationHtml = "The classical <b>Waterfall Model</b> is a linear, sequential design approach where progress flows steadily downwards starting from analysis to maintenance."
        ),
        Question(
            id = 115,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which SDLC methodology focuses on iterative development, rapid delivery, and high flexibility to changing user requirements?",
            options = listOf(
                "Waterfall Model",
                "Direct Cutover",
                "Agile Methodologies",
                "System Flowcharting"
            ),
            correctIndex = 2,
            explanationHtml = "<b>Agile</b> models promote continuous iterations of development and testing throughout the software life cycle, delivering small increments of working units."
        ),
        Question(
            id = 116,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the purpose of conducting a <b>Feasibility Study</b>?",
            options = listOf(
                "To write database query commands for testing.",
                "To determine if a system is operationally, technically, and economically practical.",
                "To upgrade user workstation physical memory speeds.",
                "To configure wireless routing protocols on a local area network."
            ),
            correctIndex = 1,
            explanationHtml = "A <b>Feasibility Study</b> checks if building a product makes financial, technical, legal, and operational sense for the organization."
        ),
        Question(
            id = 117,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which feasibility type assesses whether the organization has the necessary technology and staff expertise to execute a project?",
            options = listOf(
                "Economic Feasibility",
                "Technical Feasibility",
                "Operational Feasibility",
                "Legal Feasibility"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Technical Feasibility</b> concentrates on the technical resources available to the organization (hardware, software, technical knowledge) to meet system specifications."
        ),
        Question(
            id = 118,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which feasibility type evaluates whether the development costs will be offset by the expected financial benefits?",
            options = listOf(
                "Economic Feasibility",
                "Technical Feasibility",
                "Operational Feasibility",
                "Schedule Feasibility"
            ),
            correctIndex = 0,
            explanationHtml = "<b>Economic Feasibility</b> (Cost-Benefit Analysis) investigates the project costs against long-term financial returns and operational savings."
        ),
        Question(
            id = 119,
            topic = "Information Systems and Their Applications",
            questionHtml = "A functional representative module of the proposed software built quickly to demonstrate concepts is called:",
            options = listOf(
                "DFD Model",
                "Prototype",
                "Compiled EXE",
                "Procedural Block"
            ),
            correctIndex = 1,
            explanationHtml = "A <b>Prototype</b> is an early, simplified model of software used to gather feedback and refine customer requirements before big development cycles."
        ),
        Question(
            id = 120,
            topic = "Information Systems and Their Applications",
            questionHtml = "What does <b>DFD</b> stand for in Information Systems analysis?",
            options = listOf(
                "Direct File Deployment",
                "Detailed Form Design",
                "Data Flow Diagram",
                "Digital Frequency Driver"
            ),
            correctIndex = 2,
            explanationHtml = "A <b>Data Flow Diagram (DFD)</b> is a visual representation showing how data travels through an information system, including inputs, storage, transformations, and outputs."
        ),
        Question(
            id = 121,
            topic = "Information Systems and Their Applications",
            questionHtml = "In a Data Flow Diagram, what does an open-ended rectangle represent?",
            options = listOf(
                "Entity/Boundary",
                "Process",
                "Data Store",
                "Data Flow Arrow"
            ),
            correctIndex = 2,
            explanationHtml = "In DFD notation, an open-ended rectangle (or double parallel line) represents a <b>Data Store</b> where information is kept statically."
        ),
        Question(
            id = 122,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which SDLC implementation strategy launches the system in only one branch/location first to test it before enterprise installation?",
            options = listOf(
                "Phased Implementation",
                "Pilot Implementation",
                "Direct Implementation",
                "Parallel Implementation"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Pilot Implementation</b> introduces the entire new system to a single, small group or localized site of the organization to identify bugs safely."
        ),
        Question(
            id = 123,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which type of SDLC implementation rolls out the new system in small stages or functional modules across the whole organization?",
            options = listOf(
                "Direct Cutover",
                "Pilot Implementation",
                "Parallel Implementation",
                "Phased Implementation"
            ),
            correctIndex = 3,
            explanationHtml = "In <b>Phased Implementation</b>, parts of the system are introduced slowly (e.g., department by department) over a period of time."
        ),
        Question(
            id = 124,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the main goal of the <b>Maintenance and Support</b> phase in SDLC?",
            options = listOf(
                "To rewrite the entire system database in SQL.",
                "To patch software bugs, optimize performance, and keep the system functional over time.",
                "To carry out feasibility studies and analyze market trends.",
                "To present the proto-design schema to the board directors."
            ),
            correctIndex = 1,
            explanationHtml = "<b>System Maintenance</b> is the longest lifecycle phase, focused on correcting errors, adapting to environment changes, and enhancing system functions."
        ),
        Question(
            id = 125,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which of the following is an example of an <b>Office Automation System (OAS)</b>?",
            options = listOf(
                "Microsoft Office (Word, Excel, Outlook)",
                "Oracle ERP Enterprise Cloud Suite",
                "A localized PostgreSQL database server",
                "An operating system kernel"
            ),
            correctIndex = 0,
            explanationHtml = "An <b>OAS</b> consists of hardware and software used to digitally create, store, manipulate, and relay office tasks (word processing, spreadsheet calculation, email)."
        ),
        Question(
            id = 126,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which type of maintenance is conducted to resolve actual software crashes or faulty code bugs found after release?",
            options = listOf(
                "Adaptive Maintenance",
                "Corrective Maintenance",
                "Perfective Maintenance",
                "Preventive Maintenance"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Corrective Maintenance</b> diagnoses and fixes active faults, system errors, or code bugs found during operability."
        ),
        Question(
            id = 127,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which type of maintenance updates software to run on a new operating system or library environment?",
            options = listOf(
                "Corrective Maintenance",
                "Adaptive Maintenance",
                "Perfective Maintenance",
                "Preventive Maintenance"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Adaptive Maintenance</b> adapts existing software to operate under altered environments (e.g., new operating system versions, different platforms)."
        ),
        Question(
            id = 128,
            topic = "Information Systems and Their Applications",
            questionHtml = "Enhancing performance or adding user-requested feature upgrades to an already operational system refers to:",
            options = listOf(
                "Corrective Maintenance",
                "Perfective Maintenance",
                "Preventive Maintenance",
                "Adaptive Maintenance"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Perfective Maintenance</b> modifies code to improve performance, enhance user interfaces, or add brand-new user criteria requests."
        ),
        Question(
            id = 129,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the focus of <b>Preventive Maintenance</b> in software engineering?",
            options = listOf(
                "Fixing unexpected critical errors in real-time.",
                "Rebuilding database schemas to resolve memory leaks before failures occur.",
                "Moving software to support other language platforms.",
                "Analyzing software documentation during initial planning step."
            ),
            correctIndex = 1,
            explanationHtml = "<b>Preventive Maintenance</b> prevents problems before they occur, improving maintainability, cleansing potential risks, or reorganizing active parameters."
        ),
        Question(
            id = 130,
            topic = "Information Systems and Their Applications",
            questionHtml = "In a Database-driven Information System, which component coordinates hardware, software, and SQL algorithms to handle client transactions?",
            options = listOf(
                "Data Flow Diagram",
                "DBMS (Database Management System)",
                "Static HTML markup sheet",
                "Peripheral Printer driver"
            ),
            correctIndex = 1,
            explanationHtml = "A <b>DBMS</b> is the primary platform software interface that interacts with data streams, query processors, and user terminals to coordinate database operations."
        ),
        Question(
            id = 131,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which security principle ensures that only authorized entities can view or access private system resource data?",
            options = listOf(
                "Confidentiality",
                "Integrity",
                "Availability",
                "Non-repudiation"
            ),
            correctIndex = 0,
            explanationHtml = "<b>Confidentiality</b> means keeping data secret/encrypted so that only people with correct clearance can access it."
        ),
        Question(
            id = 132,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which security concept ensures that data remains accurate, complete, and untampered during processing or storage?",
            options = listOf(
                "Availability",
                "Integrity",
                "Authorization",
                "Authenticity"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Integrity</b> is the protection of information from unauthorized alteration, corruption, or deletion, ensuring correctness and consistency."
        ),
        Question(
            id = 133,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which security concept states that computer resources and data systems must be accessible to users whenever they need them?",
            options = listOf(
                "Integrity",
                "Confidentiality",
                "Availability",
                "Encryption"
            ),
            correctIndex = 2,
            explanationHtml = "<b>Availability</b> means authorized users have timely and reliable access to systems, data, and applications whenever required."
        ),
        Question(
            id = 134,
            topic = "Information Systems and Their Applications",
            questionHtml = "An information system designed specifically to capture geographic datasets to display custom maps is called:",
            options = listOf(
                "Global Processing System (GPS)",
                "Geographic Information System (GIS)",
                "General Integrated Schema (GIS)",
                "Ground Information Sensor (GIS)"
            ),
            correctIndex = 1,
            explanationHtml = "A <b>Geographic Information System (GIS)</b> is designed to capture, store, manipulate, analyze, manage, and present spatial or geographic data."
        ),
        Question(
            id = 135,
            topic = "Information Systems and Their Applications",
            questionHtml = "What does <b>Supply Chain Management (SCM)</b> systems help organizations manage?",
            options = listOf(
                "Internal HR and staff payroll cycles.",
                "Flow of goods, materials, and services from suppliers to the final clients.",
                "Marketing databases and customer service tickets.",
                "Website content publishing schedules."
            ),
            correctIndex = 1,
            explanationHtml = "<b>SCM</b> software structures and tracks the supply line from raw materials, production, warehouse storage, up to delivery to the client."
        ),
        Question(
            id = 136,
            topic = "Information Systems and Their Applications",
            questionHtml = "A system that gathers and monitors relationship records, sales histories, and consumer patterns is called a:",
            options = listOf(
                "Customer Relationship Management (CRM) System",
                "Enterprise Resource Planning (ERP)",
                "Transaction processing model",
                "Expert Inference Engine"
            ),
            correctIndex = 0,
            explanationHtml = "<b>CRM</b> systems organize and manage all customer interactions, sales funnels, and marketing profiles to bolster client retention."
        ),
        Question(
            id = 137,
            topic = "Information Systems and Their Applications",
            questionHtml = "What type of data is raw, unorganized, and lacks standard context?",
            options = listOf(
                "Information",
                "Knowledge",
                "Data",
                "Inference Rule"
            ),
            correctIndex = 2,
            explanationHtml = "<b>Data</b> refers to unprocessed, raw facts, numbers, or characters. When processed and organized, it becomes <b>Information</b>."
        ),
        Question(
            id = 138,
            topic = "Information Systems and Their Applications",
            questionHtml = "When raw data is processed, structured, and presented in a meaningful context, it is called:",
            options = listOf(
                "Compiled Code",
                "Information",
                "Metadata",
                "Transaction Row"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Information</b> is data that has been contextually processed, organized, or styled to make it meaningful for decision-making."
        ),
        Question(
            id = 139,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the function of the <b>Knowledge Base</b> in an Expert System?",
            options = listOf(
                "To control the network communication layer.",
                "To store specific rules, facts, and expert logic relevant to the specialized field.",
                "To display high-level graphical UI charts to general managers.",
                "To compile standard source code algorithms into binary files."
            ),
            correctIndex = 1,
            explanationHtml = "The <b>Knowledge Base</b> stores the high-quality domain knowledge (facts and rules) gathered from human experts in that field."
        ),
        Question(
            id = 140,
            topic = "Information Systems and Their Applications",
            questionHtml = "The component of an Expert System that applies rules to the knowledge base to draw logical conclusions is the:",
            options = listOf(
                "Database Engine",
                "Inference Engine",
                "User Dashboard",
                "System Complier"
            ),
            correctIndex = 1,
            explanationHtml = "The <b>Inference Engine</b> is the processing brain of the Expert System; it reasons through the rules and facts to make final decisions."
        ),
        Question(
            id = 141,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the primary objective of a <b>Knowledge Management System (KMS)</b>?",
            options = listOf(
                "To automate transaction registry on a POS terminal.",
                "To capture, share, and manage collective organizational knowledge and documents.",
                "To render dynamic web pages using backend scripting.",
                "To audit the physical hardware components of an IT center."
            ),
            correctIndex = 1,
            explanationHtml = "A <b>KMS</b> helps employees access and share vital corporate information, manuals, best practices, and internal documents quickly."
        ),
        Question(
            id = 142,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which system type focuses on capturing business intelligence (BI) with dashboards, key indicators (KPIs), and target comparisons?",
            options = listOf(
                "Operating Systems",
                "Executive Information System (EIS)",
                "Transaction Processing System",
                "File Hosting Utility"
            ),
            correctIndex = 1,
            explanationHtml = "<b>EIS</b> (often merging into Business Intelligence systems) leverages graphical tools, tracking widgets, and analytical summaries for long-term decisions."
        ),
        Question(
            id = 143,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which planning phase step checks if building an App violates standard country policies, copyrights, or regional privacy rules?",
            options = listOf(
                "Technical Feasibility",
                "Economic Feasibility",
                "Legal Feasibility",
                "Operational Feasibility"
            ),
            correctIndex = 2,
            explanationHtml = "<b>Legal Feasibility</b> investigates if the software violates or conflicts with data privacy laws, contracts, copyrights, or regional codes."
        ),
        Question(
            id = 144,
            topic = "Information Systems and Their Applications",
            questionHtml = "What type of threat involves unauthorized people intercepting wireless network messages to read private business communications?",
            options = listOf(
                "Denial of Service (DoS)",
                "Eavesdropping / Sniffing",
                "Database Insertion",
                "Buffer Overflow"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Eavesdropping (or Sniffing)</b> is listening in on raw communication traffic to capture private passwords, packets, or clear text."
        ),
        Question(
            id = 145,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the main role of <b>System testing</b> in the SDLC?",
            options = listOf(
                "Reviewing financial costs and budget limits.",
                "Validating that the software runs correctly and is completely free of fatal errors.",
                "Configuring the physical hardware architecture in servers.",
                "Designing the relational tables and keys."
            ),
            correctIndex = 1,
            explanationHtml = "<b>System Testing</b> validates the system as a whole to verify it integrated perfectly, matches requirements, and operates with correct outputs."
        ),
        Question(
            id = 146,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which type of system testing is conducted by actual clients in their real work context before final acceptance?",
            options = listOf(
                "Unit Testing",
                "Integration Testing",
                "User Acceptance Testing (UAT)",
                "Syntax Verification"
            ),
            correctIndex = 2,
            explanationHtml = "<b>User Acceptance Testing (UAT)</b> is the final tier of testing where actual users run the system to ensure it fulfills real business situations."
        ),
        Question(
            id = 147,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the purpose of **System Documentation** in Information Systems?",
            options = listOf(
                "To delete unused source code statements.",
                "To explain how a system is built, works, and can be maintained/used by programmers and users.",
                "To increase compiler loading speed.",
                "To format database rows into single normal forms."
            ),
            correctIndex = 1,
            explanationHtml = "<b>System Documentation</b> includes technical manuals, user guides, code descriptions, and architectural records needed to maintain and use the system."
        ),
        Question(
            id = 148,
            topic = "Information Systems and Their Applications",
            questionHtml = "A technique where developers pretend to be malicious hackers to find vulnerabilities in a company's systems is called:",
            options = listOf(
                "Phased Implementation",
                "Penetration Testing / Ethical Hacking",
                "Reverse Engineering",
                "Inference Analysis"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Penetration Testing (Ethical Hacking)</b> is a simulated attack used to identify and fix security gaps before real attackers find them."
        ),
        Question(
            id = 149,
            topic = "Information Systems and Their Applications",
            questionHtml = "Which of the following is considered an **Administrative Standard Control** for securing Information Systems?",
            options = listOf(
                "Configuring full network data encryption.",
                "Writing strict corporate password policies and hosting training seminars.",
                "Setting up physical fence lines and locks around servers.",
                "Installing dedicated antimalware firewalls."
            ),
            correctIndex = 1,
            explanationHtml = "<b>Administrative Controls</b> are policies, procedures, and staff training guidelines designed by management to improve safety standards."
        ),
        Question(
            id = 150,
            topic = "Information Systems and Their Applications",
            questionHtml = "What is the ultimate purpose of **Information Security** (the CIA Triad)?",
            options = listOf(
                "To replace old monitors with LCD displays.",
                "To protect the confidentiality, integrity, and availability of critical information.",
                "To compile software code safely into system binaries.",
                "To increase web hosting data limits."
            ),
            correctIndex = 1,
            explanationHtml = "The central goals of InfoSec are represented by the **CIA Triad**: safeguarding **Confidentiality**, **Integrity**, and **Availability**."
        )
    )
}
