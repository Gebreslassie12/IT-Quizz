package com.example

object Topic4Questions {
    val questions = listOf(
        Question(
            id = 401,
            topic = "Web Authoring",
            questionHtml = "What does <b>HTML</b> stand for?",
            options = listOf(
                "HighText Machine Language",
                "HyperText Markup Language",
                "Hyperlink Transfer Model Language",
                "Home Tool Management Layout"
            ),
            correctIndex = 1,
            explanationHtml = "<b>HTML</b> stands for <b>HyperText Markup Language</b>. It is the core formatting language used to construct standard web pages."
        ),
        Question(
            id = 402,
            topic = "Web Authoring",
            questionHtml = "Which standard language is used to set the visual presentation, colors, fonts, and layout styles of an HTML document?",
            options = listOf(
                "SQL",
                "Cascading Style Sheets (CSS)",
                "HyperText Transfer Protocol (HTTP)",
                "C++ Compiler"
            ),
            correctIndex = 1,
            explanationHtml = "While HTML structures the webpage content, <b>CSS (Cascading Style Sheets)</b> manages the exact styles, alignments, screens response, and visual designs."
        ),
        Question(
            id = 403,
            topic = "Web Authoring",
            questionHtml = "What type of programming language is <b>JavaScript</b> in modern web development?",
            options = listOf(
                "A database query command tool.",
                "A client-side scripting language that adds interactivity and dynamic behaviors to web pages.",
                "System firmware designed to update BIOS parameters.",
                "An offline physical disk diagnostics system."
            ),
            correctIndex = 1,
            explanationHtml = "<b>JavaScript</b> compiles inside browsers to alter HTML content dynamically, control multimedia, handle form validation, and power web apps."
        ),
        Question(
            id = 404,
            topic = "Web Authoring",
            questionHtml = "Which HTML tag is used to define the largest heading on a webpage?",
            options = listOf(
                "&lt;head&gt;",
                "&lt;heading&gt;",
                "&lt;h1&gt;",
                "&lt;h6&gt;"
            ),
            correctIndex = 2,
            explanationHtml = "HTML headings range from <b>&lt;h1&gt;</b> (largest, most important) down to <b>&lt;h6&gt;</b> (smallest, least structured)."
        ),
        Question(
            id = 405,
            topic = "Web Authoring",
            questionHtml = "Which HTML tag is used to create a hyperlink linking to another web address?",
            options = listOf(
                "&lt;link&gt;",
                "&lt;a&gt; (anchor tag)",
                "&lt;href&gt;",
                "&lt;url&gt;"
            ),
            correctIndex = 1,
            explanationHtml = "The anchor tag <b>&lt;a&gt;</b> uses the 'href' attribute to define destination URLs for active web links."
        ),
        Question(406, "Web Authoring", "What attribute inside an anchor tag &lt;a&gt; specifies the destination URL of a link?", listOf("src", "href", "alt", "linkTo"), 1, "The **href** (hypertext reference) attribute contains the actual URL destination web address."),
        Question(407, "Web Authoring", "Which HTML tag is used to display an image on a web page?", listOf("&lt;picture&gt;", "&lt;image&gt;", "&lt;img&gt;", "&lt;src&gt;"), 2, "The **&lt;img&gt;** tag is an empty/self-closing element that displays graphics using the **src** attribute."),
        Question(408, "Web Authoring", "Which attribute inside the &lt;img&gt; tag provides descriptive text if an image fails to load or for screen readers?", listOf("src", "alt", "title", "description"), 1, "The **alt** (alternative text) attribute is critical for accessibility, describing images for blind users and search-engine spiders."),
        Question(409, "Web Authoring", "To create a bulleted, **unordered list** in HTML, which parent tag must be declared?", listOf("&lt;ol&gt;", "&lt;list&gt;", "&lt;ul&gt;", "&lt;dl&gt;"), 2, "An unordered bulleted list is defined with the **&lt;ul&gt;** tag, and child list items are defined with **&lt;li&gt;**."),
        Question(410, "Web Authoring", "To create a numbered, **ordered list** in HTML, which parent tag is used?", listOf("&lt;ul&gt;", "&lt;ol&gt;", "&lt;number&gt;", "&lt;li&gt;"), 1, "An ordered numbered list is nested in **&lt;ol&gt;** tags, matching consecutive numeric list labels."),
        Question(411, "Web Authoring", "Which HTML element is used to group list items inside either &lt;ul&gt; or &lt;ol&gt; parent lists?", listOf("&lt;item&gt;", "&lt;li&gt;", "&lt;list-item&gt;", "&lt;bullet&gt;"), 1, "The **&lt;li&gt;** (list item) tag represents list items within ordered or unordered list components."),
        Question(412, "Web Authoring", "Which HTML tag represents the container for structural table rows?", listOf("&lt;table&gt;", "&lt;tr&gt;", "&lt;td&gt;", "&lt;th&gt;"), 1, "Table rows are constructed with **&lt;tr&gt;** (table row), nesting table data cells inside."),
        Question(413, "Web Authoring", "Which HTML tag is used to define a standard data cell inside a table row?", listOf("&lt;cell&gt;", "&lt;tr&gt;", "&lt;td&gt;", "&lt;table-data&gt;"), 2, "Table cells are declared using **&lt;td&gt;** (table data), representing columns of data."),
        Question(414, "Web Authoring", "What is the correct HTML tag used to insert a line break on a page, without creating a new paragraph block?", listOf("&lt;break&gt;", "&lt;lb&gt;", "&lt;br&gt;", "&lt;hr&gt;"), 2, "The **&lt;br&gt;** tag is a self-closing structural tag that forces a line break immediately."),
        Question(415, "Web Authoring", "What does the **&lt;hr&gt;** HTML tag create on a webpage?", listOf("A header row inside tables.", "A horizontal thematic rule or thin divider line.", "A high-resolution image link.", "A scrolling paragraph block."), 1, "The **&lt;hr&gt;** tag is a blank element that renders a horizontal divider sheet separating sections."),
        Question(416, "Web Authoring", "Which of the following is the correct HTML for creating a text input field?", listOf("&lt;textbox&gt;", "&lt;input type=\"text\"&gt;", "&lt;text-input&gt;", "&lt;field&gt;"), 1, "HTML forms capture text feedback using the versatile input element with **type=\"text\"**."),
        Question(417, "Web Authoring", "What block-level HTML tag is commonly used as a generic container to group webpage elements together for styling or layout?", listOf("&lt;span&gt;", "&lt;div&gt;", "&lt;section&gt;", "&lt;box&gt;"), 1, "The **&lt;div&gt;** (division) is a generic block-level element container that starts on a new line and spans full available width."),
        Question(418, "Web Authoring", "What inline HTML tag is commonly used as a generic container to style small fragments of text inside a paragraph?", listOf("&lt;div&gt;", "&lt;span&gt;", "&lt;text&gt;", "&lt;small&gt;"), 1, "The **&lt;span&gt;** element is an inline container that does not break lines, perfect for styling targeted words."),
        Question(419, "Web Authoring", "In CSS, what selector is used to apply a style rule to one single-specific element containing a unique identifier attribute?", listOf("Class selector (.)", "ID selector (#)", "Tag selector", "Universal selector (*)"), 1, "The **ID selector (#)** targets a specific element whose **id** attribute matches the selector exactly."),
        Question(420, "Web Authoring", "In CSS, what selector symbol is used to apply style rules to multiple elements grouped under the same class name?", listOf("Hash sign (#)", "Dot / Period (.)", "Asterisk (*)", "Percentage (%)"), 1, "The **class selector (.)** styles multiple elements that contain a matching **class** attribute on a page."),
        Question(421, "Web Authoring", "In the CSS box model, what behaves as the space directly inside the margin, separating the border from the actual element content?", listOf("Padding", "Spacing", "Content width", "Outline"), 0, "The CSS box model features **content**, bounded by **padding**, bounded by **border**, bounded by outer **margin**."),
        Question(422, "Web Authoring", "Which CSS property is used to set the background color of a webpage element?", listOf("color", "background-color", "bg-color", "fill-color"), 1, "The CSS property **background-color** defines color tones for element backdrops."),
        Question(423, "Web Authoring", "Which CSS property is used to change the text color of an element?", listOf("font-color", "text-color", "color", "foreground"), 2, "In CSS, the property to style text color is simply **color**."),
        Question(424, "Web Authoring", "Which CSS property changes the font thickness or weight of a text block?", listOf("font-style", "font-weight", "text-bold", "font-width"), 1, "The **font-weight** property accepts weights like **bold**, **medium**, **normal**, or numeric ranges (100 to 1000)."),
        Question(425, "Web Authoring", "Which CSS property controls the size dimensions of text (e.g., setting font size to 16px)?", listOf("font-style", "text-size", "size", "font-size"), 3, "The **font-size** property defines layout sizes for text blocks in px, em, rem, or percentage measurements."),
        Question(426, "Web Authoring", "How do you write a standard comment inside a CSS file that is ignored by web browsers?", listOf("// This is a comment", "/* This is a comment */", "&lt;!-- This is a comment --&gt;", "# This is a comment"), 1, "CSS comments start with **/** and terminate with ***/**, supporting multi-line explanations."),
        Question(427, "Web Authoring", "How do you write a comment inside an HTML document that is skipped during browser layout rendering?", listOf("// This is a comment", "/* This is a comment */", "&lt;!-- This is a comment --&gt;", "# This is a comment"), 2, "HTML documents use comments matching the syntax **&lt;!-- comment text --&gt;**."),
        Question(428, "Web Authoring", "What is the primary role of the **&lt;head&gt;** element in an HTML document?", listOf("To display the biggest visual screen header banner.", "To hold document metadata, title declarations, charset types, and CSS file links.", "To render the primary page content.", "To execute javascript calculations."), 1, "The **&lt;head&gt;** tag wraps non-visible metadata, links stylesheets, declares charsets, and sets browser tab titles."),
        Question(429, "Web Authoring", "Where is the main user-visible webpage content structured inside an HTML document?", listOf("Inside &lt;head&gt; tags.", "Inside &lt;body&gt; tags.", "Inside &lt;meta&gt; elements.", "Inside &lt;footer&gt; elements."), 1, "All user-visible elements (images, titles, checklists, paragraphs) are nested within the **&lt;body&gt;&lt;/body&gt;** boundary."),
        Question(430, "Web Authoring", "What HTML5 element is commonly used to group navigation links on a website?", listOf("&lt;navigation&gt;", "&lt;nav&gt;", "&lt;menu&gt;", "&lt;links&gt;"), 1, "The **&lt;nav&gt;** element is a semantic tag introduced in HTML5 for block grouping site navigation links."),
        Question(431, "Web Authoring", "Which HTML tag is used to create a button on which users can click?", listOf("&lt;click&gt;", "&lt;input type=\"btn\"&gt;", "&lt;button&gt;", "&lt;a href=\"button\"&gt;"), 2, "The standard interactive element is defined with the **&lt;button&gt;** tag, wrapping custom text label components."),
        Question(432, "Web Authoring", "What JavaScript statement is used to display diagnostic debug messages inside the web browser's inspector console?", listOf("alert()", "console.log()", "document.write()", "print()"), 1, "Developers use **console.log()** to test values and inspect warnings inside browser debugger consoles."),
        Question(433, "Web Authoring", "In JavaScript, what function displays an interactive pop-up alert dialog box on the user's screen?", listOf("alert()", "popup()", "message()", "showDialog()"), 0, "The **alert()** method displays a modal diagnostic dialog box with an 'OK' button."),
        Question(434, "Web Authoring", "Which JavaScript keyword is used to declare a variable that has a block scope and can be updated recursively?", listOf("var", "let", "const", "def"), 1, "Introduced in ES6, **let** declares block-scoped variables that can be modified, making it safer than legacy var."),
        Question(435, "Web Authoring", "Which JavaScript keyword is used to declare a constant variable that cannot be reassigned after declaration?", listOf("var", "let", "const", "constant"), 2, "The **const** keyword locks variable references, preventing them from being reassigned later."),
        Question(436, "Web Authoring", "What is the **DOM** in web development?", listOf("Data Object Mode", "Document Object Model", "Digital Output Master", "Domain Object Mapping"), 1, "The **Document Object Model (DOM)** is an API structure created by browsers, representing the HTML tree as nodes for JavaScript to interact with and modify."),
        Question(437, "Web Authoring", "What browser API is used in JavaScript to select an HTML element based on its unique id attribute?", listOf("document.select()", "document.getElementById()", "document.getClass()", "window.getId()"), 1, "The DOM method **document.getElementById('id')** retrieves a single element matching that ID."),
        Question(438, "Web Authoring", "Which CSS property is used to align text blocks (e.g., centering headings)?", listOf("font-align", "text-align", "align-text", "vertical-align"), 1, "The **text-align** property accepts options like **left**, **right**, **center**, and **justify**."),
        Question(439, "Web Authoring", "What CSS property defines the border style surrounding an element (e.g., solid or dashed)?", listOf("border-style", "border-width", "outline", "border-type"), 0, "The **border-style** property accepts values like **solid**, **dotted**, **dashed**, and **double**."),
        Question(440, "Web Authoring", "To link an external Cascading Style Sheet (.css) file to an HTML file, where do you insert the &lt;link&gt; tag?", listOf("At the very end of the HTML body block.", "Inside the &lt;head&gt; tags.", "Inside the &lt;title&gt; element.", "Directly inside standard paragraph blocks."), 1, "The CSS link element **&lt;link rel=\"stylesheet\" href=\"style.css\"&gt;** is inserted inside the metadata **&lt;head&gt;&lt;/head&gt;** container."),
        Question(441, "Web Authoring", "Which of the following represents an inline CSS styling method?", listOf("&lt;style&gt; p { color: red; } &lt;/style&gt;", "&lt;p style=\"color: red;\"&gt;", "&lt;link rel=\"stylesheet\"&gt;", "p { color: red; } code as an external file"), 1, "Inline CSS applies styles locally using the **style** attribute directly on the HTML tag."),
        Question(442, "Web Authoring", "Which CSS property wraps words so that they fit into container boxes, setting boundaries to prevent visual line overlaps?", listOf("word-wrap / overflow-wrap", "text-justify", "line-height", "display-inline"), 0, "The CSS **overflow-wrap** (or legacy **word-wrap**) property forces long words to break and wrap to the next line if they exceed container dimensions."),
        Question(443, "Web Authoring", "Which CSS property is used to render an element as a flexible flexbox layout, letting elements expand and shrink responsively?", listOf("display: block", "display: flex", "flex-flow: auto", "float: left"), 1, "Declaring **display: flex** makes the element a flex container, enabling direct parent-level alignment configurations for child nodes."),
        Question(444, "Web Authoring", "In Flexbox, which CSS property defines the primary axis direction of child items (e.g., laying items horizontally vs vertically)?", listOf("flex-layout", "flex-direction", "justify-content", "align-items"), 1, "The **flex-direction** property sets the main axis layout, accepting values like **row**, **row-reverse**, **column**, or **column-reverse**."),
        Question(445, "Web Authoring", "In Flexbox, which CSS property is used to align items along the primary axis (main-axis) of the flex container?", listOf("align-items", "justify-content", "flex-align", "grid-align"), 1, "The **justify-content** property aligns items along the primary axis (e.g., center, space-between, space-around)."),
        Question(446, "Web Authoring", "In JavaScript, what operator checks if two values are equal, and ALSO checks if they share the exact same data type?", listOf("=", "==", "===", "!="), 2, "While **==** performs type coercion, the strict equality operator **===** evaluates to true only if both value and data type are identical."),
        Question(447, "Web Authoring", "Which event handler triggers in JavaScript when a user clicks on an HTML button element?", listOf("onhover", "onchange", "onclick", "onsubmit"), 2, "The **onclick** event handler registers listener functions that run when the user clicks that element."),
        Question(448, "Web Authoring", "What is the correct HTML entity code used to render a less-than symbol ('&lt;') safely in text blocks?", listOf("&amp;lt;", "&amp;gt;", "&amp;amp;", "&amp;less;"), 0, "To bypass HTML parsing errors, the escape entity **&amp;lt;** is used to print lower-than brackets (&lt;)."),
        Question(449, "Web Authoring", "What HTML element is used to insert a client-side executable JavaScript block directly into a webpage?", listOf("&lt;js&gt;", "&lt;javascript&gt;", "&lt;script&gt;", "&lt;code&gt;"), 2, "HTML documents wrap scripting languages inside **&lt;script&gt;&lt;/script&gt;** tags, loading local or external scripts."),
        Question(450, "Web Authoring", "Which HTML5 API allows web applications to store up to 5-10MB of key-value data directly inside the browser permanently, persisting even after tab closures?", listOf("Session Storage", "Local Storage", "Cookie Storage", "FTP Repository"), 1, "HTML5 **localStorage** persists key-value data permanently in the browser context with no expiration date.")
    )
}
