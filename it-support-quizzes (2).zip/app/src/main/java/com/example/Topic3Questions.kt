package com.example

object Topic3Questions {
    val questions = listOf(
        Question(
            id = 301,
            topic = "Database Management System",
            questionHtml = "What is a <b>Database Management System (DBMS)</b>?",
            options = listOf(
                "A physical hard drive component used to boost read times.",
                "System software for creating, managing, retrieving, and updating databases securely.",
                "A compiler that translates C++ logic down to machine files.",
                "A design framework used exclusively for styling website banners."
            ),
            correctIndex = 1,
            explanationHtml = "A <b>DBMS</b> is a software system (like MySQL, Oracle, PostgreSQL or Room) that provides users and programmers with a systematic way to store, modify, and fetch data."
        ),
        Question(
            id = 302,
            topic = "Database Management System",
            questionHtml = "In a database table, what does a single <b>row (record)</b> represent?",
            options = listOf(
                "A specific property or attribute of the table.",
                "A single set of related data for one entity (e.g., one student's complete details).",
                "The entire relational layout of the database schema.",
                "An index list sorting all table keys."
            ),
            correctIndex = 1,
            explanationHtml = "A <b>row</b> (also called a tuple or record) represents a single, complete structured item in a table (e.g., one specific student record)."
        ),
        Question(
            id = 303,
            topic = "Database Management System",
            questionHtml = "In a database table, what does a single <b>column (field)</b> represent?",
            options = listOf(
                "The total number of records stored locally.",
                "A specific attribute, characteristic, or property of the entity (e.g., Student Age).",
                "A unique physical location on a magnetic hard drive platter.",
                "A security backup key stored offline."
            ),
            correctIndex = 1,
            explanationHtml = "A <b>column</b> (also called an attribute or field) represents a specific data dimension or property shared by all records in that table."
        ),
        Question(
            id = 304,
            topic = "Database Management System",
            questionHtml = "What is a <b>Primary Key</b> in a relational database?",
            options = listOf(
                "A key used physically to unlock the server room door.",
                "A field (or group of fields) that uniquely identifies every single row in a table.",
                "An index used to organize columns alphabetically.",
                "The first letter of a table name."
            ),
            correctIndex = 1,
            explanationHtml = "A <b>Primary Key</b> is a unique field that guarantees no two rows inside a table have the same identifying value, and it cannot contain NULL values."
        ),
        Question(
            id = 305,
            topic = "Database Management System",
            questionHtml = "Which of the following is a primary rule of a Primary Key?",
            options = listOf(
                "It can be modified at any time by web users.",
                "It must contain unique non-null values for every record.",
                "It must consist strictly of letters.",
                "It can contain multiple duplicate values in the same table."
            ),
            correctIndex = 1,
            explanationHtml = "To maintain structural integrity, a Primary Key must be completely unique for every single row and cannot contain null values."
        ),
        Question(306, "Database Management System", "What is a <b>Foreign Key</b> in relational databases?", listOf("A backup encryption key used to protect files.", "A field in one table that uniquely references the primary key of another table, creating a relationship.", "A secondary key used when primary storage fails.", "An index used to search databases from foreign countries."), 1, "A <b>Foreign Key</b> establishes a connection between tables by linking a column in one table to the primary key column of another."),
        Question(307, "Database Management System", "What type of relationship is constructed when one teacher can manage many students, but each student has only that one teacher?", listOf("Many-to-Many", "One-to-One", "One-to-Many", "Many-to-One"), 2, "A <b>One-to-Many</b> relationship links one parent record (e.g., one teacher) to multiple child records (e.g., many students)."),
        Question(308, "Database Management System", "What relationship exists between Students and Courses, where a student can enroll in many courses, and a course contains many students?", listOf("One-to-One", "One-to-Many", "Many-to-Many", "No Relationship"), 2, "Since many students link to many courses, this represents a <b>Many-to-Many</b> relationship, usually resolved with a junction table."),
        Question(309, "Database Management System", "What is the primary language used to write queries and manage relational database systems?", listOf("Hypertext Markup Language (HTML)", "Structured Query Language (SQL)", "Cascading Style Sheets (CSS)", "Python Compiler Syntax"), 1, "<b>SQL</b> is the standard language used to define, query, edit, and control database systems."),
        Question(310, "Database Management System", "Which SQL command is used to fetch and retrieve existing records from a database table?", listOf("INSERT", "UPDATE", "SELECT", "DELETE"), 2, "The <b>SELECT</b> statement is the most common SQL statement, used to retrieve rows from one or more tables."),
        Question(311, "Database Management System", "Which SQL command is used to add new records into a database table?", listOf("ADD NEW", "INSERT INTO", "UPDATE ROW", "CREATE FILE"), 1, "<b>INSERT INTO</b> is the standard SQL operation to add brand new rows of data into a table."),
        Question(312, "Database Management System", "Which SQL command is used to modify or edit existing data currently inside a table?", listOf("CHANGE", "MODIFY", "UPDATE", "REPLACE"), 2, "The <b>UPDATE</b> command modifies data values inside existing table rows, often filtered by a WHERE condition."),
        Question(313, "Database Management System", "Which SQL keyword is used to filter query results so that only records meeting specific criteria are returned?", listOf("HAVING", "WHERE", "IF", "GROUP BY"), 1, "The <b>WHERE</b> clause filters query outputs, returning only rows that evaluate as true to the specified condition."),
        Question(314, "Database Management System", "The process of organizing data in a database to avoid redundancy and ensure logical dependency is called:", listOf("Database Defragmentation", "Database Normalization", "Query Parsing", "Data Overlap"), 1, "<b>Normalization</b> divides big tables into smaller ones and defines relationships, minimizing duplicate data of columns."),
        Question(315, "Database Management System", "Which normalization form requires removing duplicate columns and ensuring all data cells contain atomic (indivisible) values?", listOf("First Normal Form (1NF)", "Second Normal Form (2NF)", "Third Normal Form (3NF)", "Boyce-Codd Normal Form"), 0, "To reach <b>1NF</b>, tables must have atomic values (no lists or comma-split values) and unique column names with a primary key."),
        Question(316, "Database Management System", "To reach **Second Normal Form (2NF)**, what structural condition must be satisfied first?", listOf("It must remove all duplicate tables.", "It must be in First Normal Form (1NF) and eliminate partial key dependencies.", "It must contain at least three primary foreign keys.", "It must write all data into plain XML files."), 1, "<b>2NF</b> requires the table to be in 1NF and all non-key columns must rely fully on the entire primary key, eliminating partial dependencies in composite keys."),
        Question(317, "Database Management System", "A collection of fields that uniquely identifies a row, of which one is chosen as the primary key, is called a:", listOf("Foreign Key", "Candidate Key", "Secondary Index", "Null Parameter"), 1, "A <b>Candidate Key</b> is any unique field combination that is qualified to act as the primary key of a table."),
        Question(318, "Database Management System", "What database property ensures that a foreign key value must always reference a valid, existing primary key in the related table?", listOf("Security Encryption", "Referential Integrity", "Index Optimization", "Transitive Dependency"), 1, "<b>Referential Integrity</b> ensures that relationships between tables remain consistent, preventing orphan foreign key records."),
        Question(319, "Database Management System", "What type of key consists of two or more columns combined together to uniquely identify rows in a table?", listOf("Primary Index", "Composite Key", "Junction Column", "Shared Foreign Key"), 1, "A <b>Composite Key</b> combines multiple columns to create a unique identifier, common in link or junction tables."),
        Question(320, "Database Management System", "Which database system does NOT use classical tables, rows, and SQL commands, but stores unstructured data (like JSON or key-value structures)?", listOf("RDBMS", "NoSQL (Not Only SQL)", "SQL Server", "MySQL"), 1, "<b>NoSQL databases</b> (like MongoDB, Firebase Firestore) store non-tabular data (documents, graphs, key-value keys) for flexible schemas."),
        Question(321, "Database Management System", "In SQL, which command is used to completely erase a database table's structure alongside all of its data?", listOf("DELETE TABLE", "TRUNCATE", "DROP TABLE", "REMOVE"), 2, "<b>DROP TABLE</b> deletes the table structure, metadata, indexes, and all rows permanently from the schema."),
        Question(322, "Database Management System", "In SQL, which clause is used to sort the retrieved records in ascending or descending order?", listOf("SORT BY", "ORDER BY", "GROUP BY", "ARRANGE BY"), 1, "The <b>ORDER BY</b> clause sorts the query results based on one or more columns in ASC (default) or DESC order."),
        Question(323, "Database Management System", "Which SQL command is used to remove specific existing rows from a table without deleting the structural table itself?", listOf("DROP", "DELETE", "REMOVE ROW", "TRUNCATE TABLE"), 1, "The <b>DELETE</b> statement removes specific rows from a table, filtered by a WHERE condition, leaving the columns intact."),
        Question(324, "Database Management System", "What SQL keyword can be used with SELECT to return only unique, non-duplicate values for a column?", listOf("UNIQUE", "DISTINCT", "DIFFERENT", "SINGLE"), 1, "The <b>DISTINCT</b> keyword filters out duplicate output rows, returning only unique values from the column."),
        Question(325, "Database Management System", "What SQL function returns the total count of rows that match a specific criteria?", listOf("SUM()", "COUNT()", "TOTAL()", "ADD()"), 1, "<b>COUNT()</b> is an aggregate function that returns the number of rows matching the query's WHERE condition."),
        Question(326, "Database Management System", "Which of the following database systems is an example of an open-source Relational Database Management System (RDBMS)?", listOf("Windows Defender", "MySql / PostgreSQL", "HTML5 Web Storage", "Adobe Reader"), 1, "MySQL, PostgreSQL, and SQLite are prominent open-source <b>relational</b> databases using SQL."),
        Question(327, "Database Management System", "What occurs during a <b>transitive dependency</b> in database normalization?", listOf("A non-key column depends on another non-key column instead of the primary key.", "A primary key references multiple tables.", "A row is deleted due to foreign key deletion.", "A column contains non-atomic data."), 0, "A transitive dependency exists when attribute A determines B, and B determines C, meaning non-key attribute C depends transitively on A."),
        Question(328, "Database Management System", "To reach **Third Normal Form (3NF)**, what criteria must be satisfied?", listOf("It must contain binary indexes.", "It must be in 2NF and contain no transitive dependencies.", "It must compile all queries in memory.", "It must not use any foreign keys."), 1, "<b>3NF</b> requires the table to be in 2NF and contains zero transitive dependencies, meaning non-prime attributes must depend solely on the primary key."),
        Question(329, "Database Management System", "In databases, what does **redundancy** refer to?", listOf("Data security measures that prevent file hacking.", "The unnecessary duplication of the exact same data in multiple database locations.", "Speeding up SQL queries using hardware caches.", "The loss of data during server software crashes."), 1, "Redundancy is the storage of duplicate data across different tables, leading to excess storage use and entry errors during updates."),
        Question(330, "Database Management System", "What database risk is introduced when redundant data is updated in one location but left unchanged in another?", listOf("Data Encryption", "Data Inconsistency / Anomaly", "Referential Integrity", "Database compression success"), 1, "Redundancy leads to update, insertion, and deletion **anomalies**, resulting in inconsistent and corrupt records."),
        Question(331, "Database Management System", "Which SQL operator is used to search for a specific character pattern in a column (e.g., finding names starting with 'A')?", listOf("EQUAL", "LIKE", "BETWEEN", "MATCH"), 1, "The <b>LIKE</b> operator is used in a WHERE clause along with wildcards (e.g., % representing zero or more characters) to search for patterns."),
        Question(332, "Database Management System", "In matching patterns with the SQL LIKE operator, which wildcard character represents exactly one single character?", listOf("Percent sign (%)", "Underscore (_)", "Asterisk (*)", "Question mark (?)"), 1, "In standard SQL LIKE syntax, **%** matches any sequence of characters, while **_** matches exactly one character."),
        Question(333, "Database Management System", "Which SQL keyword is used to combine rows from two or more tables based on a related column between them?", listOf("MERGE", "UNION", "JOIN", "CONNECT"), 2, "A <b>JOIN</b> clause combines columns from tables based on matching foreign and primary key records."),
        Question(334, "Database Management System", "What SQL command is used to add, delete, or modify columns in an existing database table?", listOf("ALTER TABLE", "UPDATE TABLE", "SET TABLE", "CHANGE SCHEMA"), 0, "The <b>ALTER TABLE</b> statement is a Data Definition Language (DDL) command used to change columns in an existing table."),
        Question(335, "Database Management System", "Which database index type speeds up data retrieval but slows down data insertions and updates because the index must be rebuilt?", listOf("System Restore", "B-Tree Indexing", "C++ Compiling", "XML parsing"), 1, "An <b>Index</b> speeds up SELECT queries greatly, but slows down INSERT/UPDATE/DELETE as the index must be kept up to date."),
        Question(336, "Database Management System", "A database column that can accept empty values without entries is said to allow:", listOf("Primary Keys", "NULL values", "Defragmentation", "Atomic indexes"), 1, "A <b>NULL</b> value represents missing, unknown, or unentered data in a database field."),
        Question(337, "Database Management System", "What SQL join type returns all records when there is a match in either left or right table records?", listOf("INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "FULL OUTER JOIN"), 3, "A <b>FULL OUTER JOIN</b> merges all records of both tables, inserting NULL where matches are absent on either side."),
        Question(338, "Database Management System", "Which SQL join returns only the rows that have matching values in both tables?", listOf("INNER JOIN", "FULL JOIN", "LEFT JOIN", "RIGHT JOIN"), 0, "An <b>INNER JOIN</b> returns rows only when the join condition is satisfied in both connecting tables."),
        Question(339, "Database Management System", "What SQL function returns the average value of a numeric column?", listOf("SUM()", "COUNT()", "AVG()", "MEAN()"), 2, "The <b>AVG()</b> aggregate function calculates and returns the mathematical average of all values in a numeric column."),
        Question(340, "Database Management System", "What does **DDL** stand for in SQL command categories?", listOf("Data Definition Language", "Database Design Layout", "Data Driver Layer", "Digital Delivery Link"), 0, "<b>DDL</b> stands for <b>Data Definition Language</b>, featuring commands like CREATE, DROP, and ALTER to define tables."),
        Question(341, "Database Management System", "What does **DML** stand for in database terminology?", listOf("Database Management Logic", "Data Manipulation Language", "Dynamic Model Linker", "Direct MySQL Loader"), 1, "<b>DML</b> stands for <b>Data Manipulation Language</b>, containing statements like SELECT, INSERT, UPDATE, and DELETE to manage data."),
        Question(342, "Database Management System", "Which of the following is categorized as a DDL command?", listOf("SELECT", "CREATE", "INSERT", "UPDATE"), 1, "<b>CREATE</b> is a DDL command because it defines database structures (tables, schemas), rather than manipulating data."),
        Question(343, "Database Management System", "A collection of databases, tables, columns, indexes, and relationships representing the entire logical database blueprint is called a:", listOf("Query layout", "Schema", "DBMS engine", "Transactional block"), 1, "A <b>Schema</b> is the formal structural design outlining tables, fields, and constraints of a database."),
        Question(344, "Database Management System", "What SQL clause is used to filter group results after grouping rows using GROUP BY?", listOf("WHERE", "HAVING", "ORDER BY", "SELECT"), 1, "While WHERE filters rows *before* grouping, <b>HAVING</b> filters grouped records *after* GROUP BY is applied."),
        Question(345, "Database Management System", "What database constraint enforces that all values in a column must be completely unique, yet allows NULL values unlike a Primary Key?", listOf("UNIQUE constraint", "NOT NULL constraint", "CHECK constraint", "FOREIGN key"), 0, "The <b>UNIQUE</b> constraint ensures all non-null values in a column are distinct, preventing duplicate entries."),
        Question(346, "Database Management System", "What database constraint restricts the type of data or range of values that can be inserted into a column (e.g., Age must be >= 18)?", listOf("FOREIGN key", "CHECK constraint", "NOT NULL constraint", "INDEX"), 1, "A <b>CHECK</b> constraint evaluates a logical expression on columns, allowing rows only if the condition is satisfied."),
        Question(347, "Database Management System", "What database phenomenon represents a set of concurrent transactions waiting infinitely for each other to release locks?", listOf("Cascade trigger", "Deadlock", "Query pipeline", "Normalization lag"), 1, "A <b>Deadlock</b> occurs when Transaction A locks Row 1 and wants Row 2, while Transaction B locks Row 2 and wants Row 1, locking both infinitely."),
        Question(348, "Database Management System", "Which of the following describes a **Database Administrator (DBA)** role?", listOf("Designing static CSS web styles.", "Configuring, backing up, securing, and maintaining corporate databases.", "Assembling computer power supply units.", "Programming mobile app layout layouts."), 1, "A <b>DBA</b> oversees database health, permissions, backups, security, and performance tuning."),
        Question(349, "Database Management System", "What SQL command is used to add security permissions to specific database users?", listOf("GRANT", "REVOKE", "SET USER", "ALLOW ACC"), 0, "The <b>GRANT</b> statement gives users access rights or query permissions for database tables."),
        Question(350, "Database Management System", "Which SQL command is used to remove previously granted database access permissions from a user?", listOf("GRANT", "REVOKE", "REMOVE PERMISSION", "DENY"), 1, "The <b>REVOKE</b> command withdraws previously assigned user privileges or database permissions.")
    )
}
