package com.example

object QuestionProvider {
    val topics = listOf(
        "Information Systems and Their Applications",
        "Emerging Technologies",
        "Database Management System",
        "Web Authoring",
        "Maintenance and Troubleshooting",
        "Fundamentals of Programming"
    )

    fun getQuestionsForTopic(topic: String): List<Question> {
        return when (topic) {
            "Information Systems and Their Applications" -> Topic1Questions.questions
            "Emerging Technologies" -> Topic2Questions.questions
            "Database Management System" -> Topic3Questions.questions
            "Web Authoring" -> Topic4Questions.questions
            "Maintenance and Troubleshooting" -> Topic5Questions.questions
            "Fundamentals of Programming" -> Topic6Questions.questions
            else -> emptyList()
        }
    }
}
