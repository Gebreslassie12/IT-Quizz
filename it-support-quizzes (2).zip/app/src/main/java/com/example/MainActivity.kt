package com.example

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Html
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: QuizViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = DarkBackground
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                            },
                            label = "screen_nav"
                        ) { screen ->
                            when (screen) {
                                is Screen.Welcome -> WelcomeLayout(
                                    onStart = { viewModel.navigateToTopicSelect() },
                                    onDialSupport = { dialTelebirr(this@MainActivity) }
                                )
                                is Screen.TopicSelect -> TopicSelectLayout(
                                    viewModel = viewModel,
                                    onTopicClick = { topic -> viewModel.startQuiz(topic) },
                                    onBack = { viewModel.resetToWelcome() },
                                    onDialSupport = { dialTelebirr(this@MainActivity) }
                                )
                                is Screen.Playing -> QuizPlayingLayout(
                                    viewModel = viewModel,
                                    topic = screen.topic,
                                    onBackToDashboard = { viewModel.navigateToTopicSelect() }
                                )
                                is Screen.ScoreResult -> ScoreResultLayout(
                                    topic = screen.topic,
                                    score = screen.score,
                                    total = screen.total,
                                    onRetry = { viewModel.startQuiz(screen.topic) },
                                    onReview = { viewModel.viewReview(screen.topic, screen.score, screen.total) },
                                    onBackHome = { viewModel.navigateToTopicSelect() },
                                    onDialSupport = { dialTelebirr(this@MainActivity) }
                                )
                                is Screen.ReviewAnswers -> ReviewLayout(
                                    topic = screen.topic,
                                    score = screen.score,
                                    total = screen.total,
                                    reviewItems = screen.reviewItems,
                                    onBackToResults = { viewModel.navigateTo(Screen.ScoreResult(screen.topic, screen.score, screen.total)) },
                                    onBackHome = { viewModel.navigateToTopicSelect() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun dialTelebirr(context: Context) {
        val encodedUssd = Uri.encode("*806*0946911419*10#")
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$encodedUssd")
        }
        context.startActivity(intent)
    }
}

// ==========================================
// CUSTOM RENDERING: HTML TEXT COMPOSABLE
// ==========================================
@Composable
fun HtmlText(
    html: String,
    modifier: Modifier = Modifier,
    textColor: Color = TextPrimary,
    fontSize: Float = 16f,
    fontWeight: FontWeight = FontWeight.Normal,
    lineHeight: Float = 22f
) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            TextView(context).apply {
                setTextColor(android.graphics.Color.WHITE)
                setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, fontSize)
                // Use standard Android typeface depending on weight
                typeface = if (fontWeight == FontWeight.Bold) {
                    android.graphics.Typeface.DEFAULT_BOLD
                } else {
                    android.graphics.Typeface.DEFAULT
                }
                setPadding(0, 0, 0, 0)
            }
        },
        update = { textView ->
            // Use legacy HTML parsing which safely supports standard tags like <b>, <i>, <code>, <small>, <br>
            textView.text = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        }
    )
}

// ==========================================
// SECTOR: TIGRAY FLAG COVER CANVAS
// ==========================================
@Composable
fun TigrayFlagCanvas(
    modifier: Modifier = Modifier,
    drawStar: Boolean = true
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        // 1. Draw vibrant red background representation
        drawRect(color = Color(0xFFD21F1F))

        // 2. Draw golden-yellow triangle starting at the left hoist
        val trianglePath = Path().apply {
            moveTo(0f, 0f)
            lineTo(0f, height)
            lineTo(width * 0.45f, height / 2f)
            close()
        }
        drawPath(path = trianglePath, color = Color(0xFFFFD700))

        if (drawStar) {
            // 3. Draw red star rotated so one vertex points fly-wards (right)
            val starCenterX = width * 0.15f
            val starCenterY = height / 2f
            val outerRadius = width * 0.055f
            val innerRadius = outerRadius * 0.42f

            val starPath = Path()
            // We rotate by Math.PI / 10 to orient star horizontally pointed
            var rot = -Math.PI / 2 + Math.PI / 10
            val step = Math.PI / 5

            for (i in 0 until 10) {
                val r = if (i % 2 == 0) outerRadius else innerRadius
                val x = starCenterX + Math.cos(rot).toFloat() * r
                val y = starCenterY + Math.sin(rot).toFloat() * r
                if (i == 0) {
                    starPath.moveTo(x, y)
                } else {
                    starPath.lineTo(x, y)
                }
                rot += step
            }
            starPath.close()
            drawPath(path = starPath, color = Color(0xFFD21F1F))
        }
    }
}

// ==========================================
// VIEW: WELCOME LAYOUT
// ==========================================
@Composable
fun WelcomeLayout(
    onStart: () -> Unit,
    onDialSupport: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App cover page using Tigray Flag
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .shadow(8.dp, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
        ) {
            TigrayFlagCanvas(modifier = Modifier.fillMaxSize())
            
            // Soft overlay gradient for cinematic title breathing room
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "GRADES 11 & 12",
                    color = TigrayGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "IT Support Quizzes",
                    color = Color.White,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 38.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Welcome Description
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            colors = CardDefaults.cardColors(containerColor = ColorSurface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Star Icon",
                        tint = TigrayGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Comprehensive Exam Prep",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Prepare fully for grades 11 and 12 IT academic exams offline. Our syllabus-aligned database features 300 curated questions split meticulously across 6 major subjects. Test your knowledge, check detailed explanations, and review your final answers instantly.",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Stats row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val stats = listOf(
                Pair("300", "Total Qs"),
                Pair("6", "Core Subjects"),
                Pair("100%", "Offline Capable")
            )
            stats.forEach { stat ->
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = ColorSurfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stat.first,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TigrayGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stat.second,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Telebirr Support Developer Donation Widget
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            colors = CardDefaults.cardColors(containerColor = ColorSurface),
            border = BorderStroke(1.dp, TigrayGold.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(TigrayGold.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Encourage",
                        tint = TigrayGold,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Encourage Developer",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Dial to donate 10 Birr via Telebirr:\n*806*0946911419*10#",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onDialSupport,
                    colors = ButtonDefaults.buttonColors(containerColor = TigrayGold),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("dial_welcome_btn")
                ) {
                    Text("Dial", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Spacer(modifier = Modifier.height(32.dp))

        // Start button
        Button(
            onClick = onStart,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(56.dp)
                .testTag("start_quizzes_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = TigrayRed),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "SELECT TOPIC",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Forward Icon",
                    tint = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

// ==========================================
// VIEW: TOPIC SELECT LAYOUT
// ==========================================
@Composable
fun TopicSelectLayout(
    viewModel: QuizViewModel,
    onTopicClick: (String) -> Unit,
    onBack: () -> Unit,
    onDialSupport: () -> Unit
) {
    val scores by viewModel.topicScores.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        // Simple Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("topic_back_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back icon",
                    tint = TextPrimary
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Choose Topic",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }

        // Mini banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .height(4.dp)
                .clip(CircleShape)
        ) {
            TigrayFlagCanvas(modifier = Modifier.fillMaxSize(), drawStar = false)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grid-like listing of subjects
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(QuestionProvider.topics.size) { index ->
                val topic = QuestionProvider.topics[index]
                val scoreEntity = scores.find { it.topicName == topic }

                val icon = when (topic) {
                    "Information Systems and Their Applications" -> Icons.Default.Settings
                    "Emerging Technologies" -> Icons.Default.Star
                    "Database Management System" -> Icons.Default.List
                    "Web Authoring" -> Icons.Default.Home
                    "Maintenance and Troubleshooting" -> Icons.Default.Build
                    "Fundamentals of Programming" -> Icons.Default.PlayArrow
                    else -> Icons.Default.Settings
                }

                val topicDesc = when (topic) {
                    "Information Systems and Their Applications" -> "TPS, MIS, DSS, SDLC life cycles, system design, and security criteria."
                    "Emerging Technologies" -> "AI models, IoT nodes, Blockchains, Cloud layers, XR experiences, and 6G."
                    "Database Management System" -> "Relational models, database normalisations, primary keys, and query statement sets."
                    "Web Authoring" -> "HTML5, modern CSS stylesheets, JavaScript scripting, DOM trees, and Web transfers."
                    "Maintenance and Troubleshooting" -> "POST startups, BSOD, physical coolants, antimalware, and disk diagnostics."
                    "Fundamentals of Programming" -> "Algorithmic flowcharts, compilers vs interpreters, OOP, variables, and recursions."
                    else -> ""
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(4.dp, RoundedCornerShape(16.dp))
                        .clickable { onTopicClick(topic) }
                        .testTag("topic_card_${index}"),
                    colors = CardDefaults.cardColors(containerColor = ColorSurface),
                    border = if (scoreEntity?.completed == true) BorderStroke(1.5.dp, TigrayGold) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(TigrayRed.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = "Subject Icon",
                                tint = TigrayGold,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = topic,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = topicDesc,
                                color = TextSecondary,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            if (scoreEntity?.completed == true) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Completed mark",
                                        tint = TigrayGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Best Score: ${scoreEntity.bestScore} / 50",
                                        color = TigrayGold,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            } else {
                                Text(
                                    text = "Ready (50 Questions)",
                                    color = TextSecondary.copy(alpha = 0.7f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Arrow Right",
                            tint = TextSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            // Quick micro donation bar inside listing
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    colors = CardDefaults.cardColors(containerColor = ColorSurfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Encourage Developer: Double tap to dial *806*",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = onDialSupport,
                            colors = ButtonDefaults.buttonColors(containerColor = TigrayGold),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("Support", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// VIEW: QUIZ PLAYING LAYOUT
// ==========================================
@Composable
fun QuizPlayingLayout(
    viewModel: QuizViewModel,
    topic: String,
    onBackToDashboard: () -> Unit
) {
    val questions by viewModel.currentQuestions.collectAsStateWithLifecycle()
    val currentIndex by viewModel.currentQuestionIndex.collectAsStateWithLifecycle()
    val selectedOption by viewModel.selectedOption.collectAsStateWithLifecycle()
    val isAnswerChecked by viewModel.isAnswerChecked.collectAsStateWithLifecycle()
    val score by viewModel.score.collectAsStateWithLifecycle()

    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = TigrayRed)
        }
        return
    }

    val question = questions[currentIndex]
    val totalQuestions = questions.size

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToDashboard,
                modifier = Modifier.testTag("quiz_back_dashboard_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Exit Quiz",
                    tint = TextPrimary
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = topic,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    text = "Score: $score / $currentIndex",
                    color = TigrayGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Progress bar container using Tigray Flag theme
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Question ${currentIndex + 1} of $totalQuestions",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "${((currentIndex + 1) * 100) / totalQuestions}% Done",
                    color = TigrayGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (currentIndex + 1).toFloat() / totalQuestions.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = TigrayGold,
                trackColor = ColorSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Question Statement Box
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .shadow(4.dp, RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = ColorSurface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Topic tag
                Box(
                    modifier = Modifier
                        .background(TigrayRed, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "GRADE 11-12 EXAM",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
                
                // Question text with HTML tags output!
                HtmlText(
                    html = question.questionHtml,
                    fontSize = 18f,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 24f
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Options listing (Only select one)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            question.options.forEachIndexed { index, option ->
                val isSelected = selectedOption == index
                
                // Color formatting determined by "Checked" state
                val borderStroke = when {
                    isAnswerChecked && index == question.correctIndex -> {
                        BorderStroke(2.dp, SuccessGreen)
                    }
                    isAnswerChecked && isSelected && index != question.correctIndex -> {
                        BorderStroke(2.dp, ErrorRed)
                    }
                    isSelected -> {
                        BorderStroke(2.dp, TigrayRed)
                    }
                    else -> null
                }

                val containerColor = when {
                    isAnswerChecked && index == question.correctIndex -> {
                        SuccessGreen.copy(alpha = 0.15f)
                    }
                    isAnswerChecked && isSelected && index != question.correctIndex -> {
                        ErrorRed.copy(alpha = 0.15f)
                    }
                    isSelected -> {
                        TigrayRed.copy(alpha = 0.1f)
                    }
                    else -> ColorSurface
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(14.dp))
                        .clickable(enabled = !isAnswerChecked) { viewModel.selectOption(index) }
                        .testTag("option_item_${index}"),
                    colors = CardDefaults.cardColors(containerColor = containerColor),
                    border = borderStroke
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Letter option avatar
                        val letter = ('A' + index).toString()
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(
                                    color = when {
                                        isAnswerChecked && index == question.correctIndex -> SuccessGreen
                                        isAnswerChecked && isSelected && index != question.correctIndex -> ErrorRed
                                        isSelected -> TigrayRed
                                        else -> ColorSurfaceVariant
                                    },
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = letter,
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        // Render choice options
                        Text(
                            text = option,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            modifier = Modifier.weight(1f)
                        )

                        if (isAnswerChecked) {
                            if (index == question.correctIndex) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Correct",
                                    tint = SuccessGreen
                                )
                            } else if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Incorrect",
                                    tint = ErrorRed
                                )
                            }
                        }
                    }
                }
            }
        }

        // Explanation Box (Shown only after answer is checked)
        if (isAnswerChecked) {
            Spacer(modifier = Modifier.height(20.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .shadow(4.dp, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = ColorSurfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Info",
                            tint = TigrayGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Concept Explanation",
                            color = TigrayGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    HtmlText(
                        html = question.explanationHtml,
                        fontSize = 14f,
                        textColor = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Action Trigger Button
        Button(
            onClick = {
                if (!isAnswerChecked) {
                    viewModel.checkAnswer()
                } else {
                    viewModel.nextQuestion(topic)
                }
            },
            enabled = selectedOption != null,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(52.dp)
                .testTag("quiz_action_btn"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (!isAnswerChecked) TigrayGold else TigrayRed,
                disabledContainerColor = ColorSurfaceVariant
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            val label = if (!isAnswerChecked) "CHECK ANSWER" else {
                if (currentIndex == totalQuestions - 1) "FINISH EXAM" else "NEXT QUESTION"
            }
            Text(
                text = label,
                color = if (!isAnswerChecked && selectedOption != null) Color.Black else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// ==========================================
// VIEW: SCORE RESULTS LAYOUT
// ==========================================
@Composable
fun ScoreResultLayout(
    topic: String,
    score: Int,
    total: Int,
    onRetry: () -> Unit,
    onReview: () -> Unit,
    onBackHome: () -> Unit,
    onDialSupport: () -> Unit
) {
    val percent = (score * 100) / total

    val resultStats = when {
        percent >= 76 -> Triple(
            "Excellent",
            TigrayGold,
            "Mastery Level! 🏆 Absolutely brilliant work! You have shown complete mastery over these curriculum topics. Keep reading to maintain excellence!"
        )
        percent in 51..75 -> Triple(
            "Very Good",
            Color(0xFFFFB300),
            "Strong Level! 🎉 Great work! You have a highly competent understanding of IT concepts. Review missed answers to perfect your knowledge!"
        )
        else -> Triple(
            "Good",
            TigrayRed,
            "Progress Level! 👍 Good attempt! It is a great starting baseline. Review the answers list and try again to improve your final credentials!"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Gorgeous top flag cover
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
        ) {
            TigrayFlagCanvas(modifier = Modifier.fillMaxSize(), drawStar = true)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "QUIZ RESULTS CALCULATED",
                    color = TigrayGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = topic,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Custom Donut score circle
        Box(
            modifier = Modifier
                .size(160.dp)
                .background(ColorSurface, CircleShape)
                .border(6.dp, resultStats.second, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$score / $total",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$percent%",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = resultStats.second
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Encuerage Score Status Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .shadow(6.dp, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = ColorSurface)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = resultStats.first.uppercase(),
                    color = resultStats.second,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = resultStats.third,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Telebirr Support Developer Donation Widget
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            colors = CardDefaults.cardColors(containerColor = ColorSurface),
            border = BorderStroke(1.dp, TigrayGold.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Encourage",
                    tint = TigrayGold,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Encourage Developer",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dial to send 10 Birr via Telebirr (*806*)",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = onDialSupport,
                    colors = ButtonDefaults.buttonColors(containerColor = TigrayGold),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("Dial", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Action Column
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onRetry,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("retry_quiz_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = TigrayGold),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Restart Quiz Icon",
                    tint = Color.Black
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("RESTART QUIZ", color = Color.Black, fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onReview,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("review_answers_result_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = ColorSurfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.List,
                        contentDescription = "Review answers Icon",
                        tint = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("REVIEW ANSWERS", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }

                Button(
                    onClick = onBackHome,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("back_to_topics_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = TigrayRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "Home",
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("TOPICS LIST", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// ==========================================
// VIEW: REVIEW ANSWERS LIST LAYOUT
// ==========================================
@Composable
fun ReviewLayout(
    topic: String,
    score: Int,
    total: Int,
    reviewItems: List<ReviewItem>,
    onBackToResults: () -> Unit,
    onBackHome: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // App top control bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToResults,
                modifier = Modifier.testTag("review_close_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Review Answers",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "$score / $total Correct answers",
                    color = TigrayGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            IconButton(
                onClick = onBackHome,
                modifier = Modifier.testTag("review_home_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Home",
                    tint = TextPrimary
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(CircleShape)
        ) {
            TigrayFlagCanvas(modifier = Modifier.fillMaxSize(), drawStar = false)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // List Answers Scroll Layout ("Put list of the answers finally")
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            itemsIndexed(reviewItems) { index, reviewItem ->
                val q = reviewItem.question
                val isCorrect = reviewItem.isCorrect

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(16.dp))
                        .testTag("review_item_${index}"),
                    colors = CardDefaults.cardColors(containerColor = ColorSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "QUESTION ${index + 1}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TigrayGold
                            )
                            
                            // Success / error badge indicator
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Close,
                                    contentDescription = if (isCorrect) "Correct" else "Incorrect",
                                    tint = if (isCorrect) SuccessGreen else ErrorRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isCorrect) "Correct" else "Missed",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCorrect) SuccessGreen else ErrorRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Render Html Question Statement
                        HtmlText(
                            html = q.questionHtml,
                            fontSize = 15f,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Selected vs correct
                        val selectedLabel = if (reviewItem.selectedIndex != null) {
                            "Your Choice: **${('A' + reviewItem.selectedIndex).toString()}** - ${q.options[reviewItem.selectedIndex]}"
                        } else {
                            "Your Choice: **None (Skipped)**"
                        }
                        val correctLabel = "Correct Answer: **${('A' + q.correctIndex).toString()}** - ${q.options[q.correctIndex]}"

                        // Selected answer text representation
                        Text(
                            text = if (reviewItem.selectedIndex != null) {
                                "Your choice: (" + ('A' + reviewItem.selectedIndex).toString() + ") " + q.options[reviewItem.selectedIndex]
                            } else {
                                "Your choice: None (Skipped)"
                            },
                            color = if (isCorrect) SuccessGreen else ErrorRed,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        if (!isCorrect) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Correct option: (" + ('A' + q.correctIndex).toString() + ") " + q.options[q.correctIndex],
                                color = SuccessGreen,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = ColorSurfaceVariant, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Display explanation
                        Text(
                            text = "Explanation:",
                            color = TigrayGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        HtmlText(
                            html = q.explanationHtml,
                            fontSize = 13f,
                            textColor = TextSecondary
                        )
                    }
                }
            }
        }
    }
}
