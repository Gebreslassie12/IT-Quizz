package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TigrayRed = Color(0xFFD21F1F)
val TigrayGold = Color(0xFFFFD700)
val DarkBackground = Color(0xFF121216)
val ColorSurface = Color(0xFF1E1E24)
val ColorSurfaceVariant = Color(0xFF2B2B36)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFC5C5D2)

val SuccessGreen = Color(0xFF2E7D32)
val ErrorRed = Color(0xFFC62828)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

