package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = TigrayRed,
  secondary = TigrayGold,
  tertiary = SuccessGreen,
  background = DarkBackground,
  surface = ColorSurface,
  onPrimary = TextPrimary,
  onSecondary = DarkBackground,
  onBackground = TextPrimary,
  onSurface = TextPrimary,
  surfaceVariant = ColorSurfaceVariant,
  onSurfaceVariant = TextSecondary
)

private val LightColorScheme = lightColorScheme(
  primary = TigrayRed,
  secondary = TigrayGold,
  tertiary = SuccessGreen,
  background = DarkBackground,
  surface = ColorSurface,
  onPrimary = TextPrimary,
  onSecondary = DarkBackground,
  onBackground = TextPrimary,
  onSurface = TextPrimary,
  surfaceVariant = ColorSurfaceVariant,
  onSurfaceVariant = TextSecondary
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Disable dynamic colors to respect branding explicitly!
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
