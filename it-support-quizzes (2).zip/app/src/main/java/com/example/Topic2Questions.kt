package com.example

object Topic2Questions {
    val questions = listOf(
        Question(
            id = 201,
            topic = "Emerging Technologies",
            questionHtml = "What is the primary characteristic of <b>Artificial Intelligence (AI)</b>?",
            options = listOf(
                "Upgrading physical computer motherboard parts.",
                "Enabling machines or computers to mimic human intelligence and decision-making.",
                "Managing SQL databases and creating primary keys.",
                "Writing strict HTML/CSS formatting rules."
            ),
            correctIndex = 1,
            explanationHtml = "<b>AI</b> is the field of computer science dedicated to building machines that mimic human capabilities like reasoning, learning, and planning."
        ),
        Question(
            id = 202,
            topic = "Emerging Technologies",
            questionHtml = "Which subfield of AI involves training algorithms to learn patterns from datasets without explicit step-by-step programming?",
            options = listOf(
                "Hypertext Transfer Protocol (HTTP)",
                "Machine Learning (ML)",
                "Local Area Network (LAN)",
                "BIOS System diagnostics"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Machine Learning (ML)</b> uses data and mathematical algorithms to help computer programs automatically improve their performance over time."
        ),
        Question(
            id = 203,
            topic = "Emerging Technologies",
            questionHtml = "What type of artificial intelligence is model-specific, built to solve only one specific task (like identifying spam emails or translation)?",
            options = listOf(
                "Artificial General Intelligence (AGI)",
                "Narrow or Weak AI",
                "Supervised Deep Mind (SDM)",
                "Quantum Neural System"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Narrow AI (or Weak AI)</b> is trained and focused on a single targeted task (e.g., Siri, self-driving cars, Chess programs)."
        ),
        Question(
            id = 204,
            topic = "Emerging Technologies",
            questionHtml = "An AI system that possesses the capability to understand, learn, and apply knowledge across any intellectual task just like a human is called:",
            options = listOf(
                "Weak AI",
                "Narrow AI",
                "Artificial General Intelligence (AGI)",
                "Decision Support System"
            ),
            correctIndex = 2,
            explanationHtml = "<b>AGI (or Strong AI)</b> is a hypothetical AI that shows intelligent behavior equivalent to a human across many diverse fields."
        ),
        Question(
            id = 205,
            topic = "Emerging Technologies",
            questionHtml = "What technology connects physical everyday objects (sensors, home appliances) to the internet to collect and share data?",
            options = listOf(
                "Enterprise Resource Planning (ERP)",
                "Internet of Things (IoT)",
                "Database Management System (DBMS)",
                "Integrated Development Environment (IDE)"
            ),
            correctIndex = 1,
            explanationHtml = "The <b>Internet of Things (IoT)</b> is a network of physical items (devices, appliances, vehicles) embedded with sensors, software, and connectivity to exchange data."
        ),
        Question(
            id = 206,
            topic = "Emerging Technologies",
            questionHtml = "In IoT, what is the role of an <b>actuator</b>?",
            options = listOf(
                "Reading atmospheric temperatures dynamically.",
                "Translating high-level programming modules into binary files.",
                "Executing a physical action or control (e.g., opening a valve, turning on a motor).",
                "Storing historical relational table information offline."
            ),
            correctIndex = 2,
            explanationHtml = "While <b>sensors</b> collect environmental data, <b>actuators</b> take control actions, translating digital signals into physical movement or operations."
        ),
        Question(
            id = 207,
            topic = "Emerging Technologies",
            questionHtml = "Which term describes massive datasets that are too large, fast, or complex to be processed by traditional database systems?",
            options = listOf(
                "Dynamic Schema",
                "Big Data",
                "Meta tags",
                "Binary Logs"
            ),
            correctIndex = 1,
            explanationHtml = "<b>Big Data</b> describes datasets characterized by high volume, high velocity, and extreme variety that require new forms of computing to process."
        ),
        Question(
            id = 208,
            topic = "Emerging Technologies",
            questionHtml = "What are the core <b>Three Vs</b> of Big Data?",
            options = listOf(
                "Value, Verification, Virtualization",
                "Volume, Velocity, Variety",
                "Vulnerability, Validity, Vector",
                "Vapor, Viewport, Version"
            ),
            correctIndex = 1,
            explanationHtml = "The three defining properties of Big Data are **Volume** (amount of data), **Velocity** (speed of data intake), and **Variety** (different formats of data)."
        ),
        Question(
            id = 209,
            topic = "Emerging Technologies",
            questionHtml = "What is a <b>Blockchain</b>?",
            options = listOf(
                "A strict physical lock used to protect servers.",
                "A decentralized, distributed, and digital ledger that records transactions securely across many computers.",
                "A process of dividing hard drives into several partitions.",
                "A model that checks HTML pages for errors."
            ),
            correctIndex = 1,
            explanationHtml = "A <b>Blockchain</b> is a decentralized ledger that stores transactions in secure, cryptographic blocks, making records transparent and immutable."
        ),
        Question(210, "Emerging Technologies", "Which key feature of Blockchain prevents details from being changed or edited once they are written?", listOf("Immutability", "Defragmentation", "Interpreting", "Virtualization"), 0, "<b>Immutability</b> means records are permanent and alteration-proof because of cryptographic block hashing and distributed network validations."),
        Question(211, "Emerging Technologies", "What model allows users to rent computer resources (storage, processing, RAM) over the internet instead of buying physical servers?", listOf("Local-first Computing", "Cloud Computing", "Physical Archiving", "Analog Processing"), 1, "<b>Cloud Computing</b> is the delivery of on-demand computing services (servers, storage, databases, networking, software) over the internet."),
        Question(212, "Emerging Technologies", "Which Cloud delivery model provides only the physical servers, storage units, and networking resources (e.g., AWS EC2)?", listOf("Software as a Service (SaaS)", "Platform as a Service (PaaS)", "Infrastructure as a Service (IaaS)", "Data as a Service (DaaS)"), 2, "<b>IaaS</b> provides clean virtual servers, storage networks, and hypervisors, giving users complete operating system control."),
        Question(213, "Emerging Technologies", "Which Cloud delivery model provides a complete environment for coding, deploying, and testing applications (e.g., Heroku, Google App Engine)?", listOf("Infrastructure as a Service (IaaS)", "Platform as a Service (PaaS)", "Software as a Service (SaaS)", "Application as a Service"), 1, "<b>PaaS</b> provides a platform allowing developers to build, run, and manage applications without managing hardware or OS setups."),
        Question(214, "Emerging Technologies", "Which Cloud delivery model offers ready-to-use software applications hosted on the internet for clients (e.g., Gmail, Google Docs)?", listOf("Infrastructure as a Service (IaaS)", "Platform as a Service (PaaS)", "Software as a Service (SaaS)", "Firmware as a Service"), 2, "<b>SaaS</b> delivers software over the internet on a subscription basis, eliminating the need to install or run programs locally."),
        Question(215, "Emerging Technologies", "What technology superimposes interactive digital elements (images, text) onto the real world (e.g., Pokémon Go, live filters)?", listOf("Virtual Reality (VR)", "Augmented Reality (AR)", "Quantum Computing", "Standard Hologram"), 1, "<b>Augmented Reality (AR)</b> augments your current real-world surroundings by overlaying computer-generated digital enhancements on top."),
        Question(216, "Emerging Technologies", "Which technology provides a fully immersive, completely simulated 3D environment that replaces the real physical world?", listOf("Augmented Reality (AR)", "Virtual Reality (VR)", "Broadband Interface", "HTML Authoring"), 1, "<b>Virtual Reality (VR)</b> uses computer technology and head-mounted displays to submerge the user inside an artificial 3D digital reality."),
        Question(217, "Emerging Technologies", "Which cellular network generation provides ultra-fast speed, low latency, and high device density for IoT and smart cities?", listOf("3G", "4G LTE", "5G", "EDGE"), 2, "<b>5G</b> cellular technology delivers high multi-Gbps peak data speeds, ultra-low latency, and support for millions of connected IoT objects."),
        Question(218, "Emerging Technologies", "What computing concept brings processing and data storage closer to the physical sensors and IoT devices instead of a centralized cloud?", listOf("Mainframe Computing", "Edge Computing", "Centralized Host", "Proxy Terminal"), 1, "<b>Edge Computing</b> processes local data locally on 'edge' devices (near the data source), minimizing latency and bandwidth use."),
        Question(219, "Emerging Technologies", "What type of computer leverages the laws of quantum mechanics (superposition and entanglement) to solve complex calculations incredibly fast?", listOf("Supercomputer", "Quantum Computer", "Mini-terminal", "Mainframe"), 1, "<b>Quantum Computers</b> utilize quantum concepts like qubits, allowing them to solve mathematical problems that are impossible for standard digital computers."),
        Question(220, "Emerging Technologies", "In quantum computing, what is the basic unit of information comparable to a classical binary bit?", listOf("Byte", "Pixel", "Qubit (Quantum Bit)", "Node"), 2, "A <b>qubit</b> is the basic unit of information in quantum computing, representing a 0, 1, or both at the same time (superposition)."),
        Question(221, "Emerging Technologies", "In Machine Learning, what is <b>Supervised Learning</b>?", listOf("Training a model on labeled datasets where the desired answers are already known.", "Allowing the computer to categorize unlabeled data without guide parameters.", "An instructor manually typing code answers into a web prompt.", "Cleaning a relational database to empty system parameters."), 0, "<b>Supervised Learning</b> trains models on pre-labeled input-output pairs so the algorithm learns to predict accurate target outputs from new inputs."),
        Question(222, "Emerging Technologies", "Which type of machine learning lets programs analyze unlabeled raw data to discover hidden clusters or patterns on their own?", listOf("Supervised Learning", "Unsupervised Learning", "Inference Programming", "Waterfall Verification"), 1, "<b>Unsupervised Learning</b> explores data that does not have pre-set labels, finding built-in trends and grouping data into categories."),
        Question(223, "Emerging Technologies", "What machine learning system trains an agent through direct trial-and-error by rewarding correct actions and penalizing errors?", listOf("Reinforcement Learning", "Supervised Learning", "Linear Regression", "Semantic Parsing"), 0, "<b>Reinforcement Learning (RL)</b> is based on rewarding good actions and punishing bad ones, guiding an agent to seek optimal behaviors."),
        Question(224, "Emerging Technologies", "What are <b>Smart Contracts</b> in the context of Blockchain?", listOf("Upgraded computer monitors that adapt contrast automatically.", "Self-executing digital contracts with terms of agreement written directly in code.", "Physical guidelines written on server partitions by networks.", "Database systems that compile SQL tables automatically."), 1, "<b>Smart Contracts</b> are lines of code on a blockchain that execute terms automatically when predefined conditions are met, removing the need for a third party."),
        Question(225, "Emerging Technologies", "Which computing system is inspired by the structure of the human brain's neural networks?", listOf("Binary microprocessors", "Artificial Neural Networks (ANN)", "Procedural controllers", "Dynamic servers"), 1, "<b>Artificial Neural Networks (ANN)</b> are cognitive processing networks built of interconnected nodes (neurons) that learn and model complex patterns."),
        Question(226, "Emerging Technologies", "What does <b>SaaS</b> stand for in Cloud Computing?", listOf("Software as an Asset Store", "Software as a Service", "System and Application Software", "Scientific Analytical Solution"), 1, "<b>SaaS</b> stands for <b>Software as a Service</b>, a popular subscription cloud software delivery method."),
        Question(227, "Emerging Technologies", "In cloud models, which of the following is typically a <b>Private Cloud</b>?", listOf("A cloud infrastructure operated solely for a single organization.", "A public cloud server shared by millions of basic web accounts.", "A cloud backup that does not run network applications.", "A storage database with public HTTP access layers."), 0, "A <b>Private Cloud</b> is cloud infrastructure provisioned for exclusive use by a single business entity, offering tighter control and security."),
        Question(228, "Emerging Technologies", "What is <b>Hybrid Cloud</b>?", listOf("Local server that operates without internet networks.", "An aggregate of public and private cloud models linked together to share resources.", "An operating system that runs mobile and desktop files.", "A computer engine utilizing solar powers."), 1, "A <b>Hybrid Cloud</b> combines private on-premise infrastructure and public cloud environments, allowing data and applications to move between them."),
        Question(
            id = 229,
            topic = "Emerging Technologies",
            questionHtml = "In IoT, a device that gathers temperature, light, pressure, or movement details is categorised as a:",
            options = listOf("Actuator", "Sensor", "CPU Core", "Router"),
            correctIndex = 1,
            explanationHtml = "A <b>Sensor</b> detects changes, events, or measurements in its physical environment and translates them into readable electrical signals."
        ),
        Question(230, "Emerging Technologies", "Which of the following is considered a key issue in big data management?", listOf("Reducing the speed of RAM processors.", "Storage scaling, data security, and preserving user privacy.", "Selecting simple font styles for websites.", "Limiting the use of mobile applications."), 1, "The sheer size and rapid influx of Big Data create challenges in **scalable storage**, **privacy compliance**, **leak prevention**, and **retrieval times**."),
        Question(231, "Emerging Technologies", "What is the primary role of a <b>data scientist</b>?", listOf("Assembling physical network cabling systems.", "Analyzing and interpreting complex big data to discover patterns and drive decisions.", "Writing simple CSS stylesheets for web pages.", "Cleaning computer fans and keyboards."), 1, "A data scientist compiles, cleans, and applies complex statistical models to Big Data to extract actionable business insights."),
        Question(232, "Emerging Technologies", "In blockchain, what is a **consensus mechanism**?", listOf("The process of deleting duplicate database columns.", "A protocol that allows blockchain nodes to agree on the validity of transactions.", "A text processor that formats smart contract layout.", "A physical lock on database hosting servers."), 1, "A <b>consensus mechanism</b> (e.g., Proof of Work, Proof of Stake) ensures that all nodes in a distributed network agree on the true state of the ledger."),
        Question(233, "Emerging Technologies", "Which consensus model requires miners to solve complex mathematical puzzles to secure blockchain transactions?", listOf("Proof of Stake (PoS)", "Proof of Work (PoW)", "Proof of Authority (PoA)", "Proof of History (PoH)"), 1, "<b>Proof of Work (PoW)</b> requires miners to spend processor power solving hard cryptographic equations, used classically by Bitcoin."),
        Question(234, "Emerging Technologies", "Which consensus model selects block creators based on the number of cryptocurrency tokens they own and pledge as collateral?", listOf("Proof of Work (PoW)", "Proof of Stake (PoS)", "Inference validation", "SQL partition system"), 1, "<b>Proof of Stake (PoS)</b> selects validators based on their stake of ownership, saving massive electricity costs compared to PoW."),
        Question(235, "Emerging Technologies", "What is **Natural Language Processing (NLP)**?", listOf("A field of AI focused on enabling computers to understand, interpret, and write human language.", "A programming language that uses plain English text instead of symbols.", "Formatting web pages using simple HTML tags.", "A method to speed up physical computer storage volumes."), 0, "<b>NLP</b> is a branch of AI that helps computers read, process, translate, and synthesize natural human languages (like English or Amharic)."),
        Question(236, "Emerging Technologies", "Which of the following is a real-world application of NLP?", listOf("Optimizing physical device driver speeds.", "Defragmenting secondary storage sectors.", "Voice-controlled digital assistants like Siri or Google Assistant.", "Generating relational database primary keys."), 2, "Digital assistants require **NLP** to parse verbal or typed requests, understand intent, and construct intelligent text answers."),
        Question(237, "Emerging Technologies", "What is **Computer Vision** in Artificial Intelligence?", listOf("Installing high-definition computer screens.", "A field of AI enabling computers to process and understand visual data from images or videos.", "Restoring display resolutions after system crashes.", "A programming standard used for designing vector vector assets."), 1, "<b>Computer Vision</b> trains AI algorithms to process, segment, and understand visual data (e.g., facial detection, autonomous vehicle camera processing)."),
        Question(238, "Emerging Technologies", "Which technology is used in self-driving cars to detect street lines, signs, and pedestrians?", listOf("Static FTP protocol", "Computer Vision and Sensors", "Disk fragmentation check", "HTML web authoring"), 1, "Self-driving cars merge **computer vision** camera streams and distance sensors (radar/lidar) in real-time to navigate safely."),
        Question(239, "Emerging Technologies", "A technology that allows 3D virtual objects to be designed and 'printed' out as physical plastic or metal items tag-by-tag is:", listOf("Augmented print", "3D Printing / Additive Manufacturing", "Laser projecting", "Raster vector rendering"), 1, "<b>3D Printing</b> builds real-world 3D objects step-by-step from CAD digital blueprints using layered filaments (plastic, resin, metal)."),
        Question(240, "Emerging Technologies", "Which of the following is an example of an **industrial IoT (IIoT)** application?", listOf("Using automated assembly line sensors to monitor machine health and predict failures.", "Typing a document inside a word processor.", "Formating an external USB memory device.", "Creating HTML website menu bars."), 0, "<b>IIoT</b> implements smart sensors, networks, and feedback loops across heavy industrial manufacturing systems to maximize productivity and track safety."),
        Question(241, "Emerging Technologies", "What does **SaaS** stand for?", listOf("System and Service Security", "Software as a Service", "Standard Automated SQL System", "Shared Application Support Suite"), 1, "SaaS provides complete, ready-to-run software accessed directly via web browsers on a subscription scale."),
        Question(242, "Emerging Technologies", "Which cloud architecture utilizes multiple different public or private cloud vendors within a single business infrastructure?", listOf("Mono-Cloud", "Multi-Cloud", "Local Host Group", "Client-Server Mesh"), 1, "A <b>Multi-Cloud</b> model deploys services across multiple distinct cloud providers (e.g., using AWS, Google Cloud, and Azure together) to prevent vendor lock-in."),
        Question(243, "Emerging Technologies", "Which technology is most critical for developing highly realistic conversational chatbots like ChatGPT?", listOf("Simple file managers", "Large Language Models (LLMs) and Deep Learning", "Defragmented storage systems", "C++ compiler drivers"), 1, "<b>LLMs</b> are trained on massive text databases to generate human-like text responses and engage in continuous conversation."),
        Question(244, "Emerging Technologies", "What does **Deep Learning** represent in AI?", listOf("A class of machine learning that utilizes deep artificial neural networks with multiple layers.", "Coding simple logical statements down in HTML.", "A database retrieval system that processes SQL tables.", "A method used to clean physical computer hardware components."), 0, "<b>Deep Learning</b> is a subset of ML based on multi-layered neural networks (hence 'deep') that can model highly complex datasets."),
        Question(245, "Emerging Technologies", "A device that detects physical changes and converts them to digital data is a ____, whereas a device that converts electrical instructions into physical movement is an ____.", listOf("Actuator, Sensor", "Sensor, Actuator", "Cabling, Connector", "Router, Transistor"), 1, "Sensors **read** the environment; Actuators **affect** or act on the environment."),
        Question(246, "Emerging Technologies", "Which of the following describes a major security concern of the Internet of Things?", listOf("IoT devices have enormous processing power.", "Many IoT devices have limited security features, weak default passwords, and are seldom patched.", "IoT gadgets do not utilize internet systems.", "All IoT devices use complex database servers."), 1, "Because they are compact and low-resource, billions of IoT devices lack security, making them targets for malware and botnets."),
        Question(247, "Emerging Technologies", "What is the primary technical objective of 6G communication technology research as an emerging tech?", listOf("Returning mobile phones to analog audio standards.", "Achieving terabit-per-second speeds, microsecond latencies, and total terrestrial coverage.", "Restricting web access to simple static web sheets.", "Reducing mobile battery lifetimes to standard thresholds."), 1, "6G targets extreme speeds (100x faster than 5G), absolute low latency, and space/satellite integration."),
        Question(248, "Emerging Technologies", "In technology ethics, the study of fairness, bias, privacy, and accountability in AI algorithms is known as:", listOf("Web Authoring Rules", "AI Ethics", "Hardware Calibration", "Compiler Diagnostics"), 1, "<b>AI Ethics</b> deals with the societal and ethical impacts of AI, targeting algorithm bias, privacy rights, and machine transparency."),
        Question(249, "Emerging Technologies", "Which blockchain application represents unique digital ownership of art or assets that cannot be exchanged?", listOf("Standard Bitcoin", "Non-Fungible Tokens (NFTs)", "SQL Row Index", "FTP secure key"), 1, "An <b>NFT</b> is a unique cryptographic token stored on a blockchain, confirming immutable ownership of a specific digital media asset."),
        Question(250, "Emerging Technologies", "Which of the following fields combines biology and IT by coding, storing, or analyzing complex DNA sequences using information models?", listOf("Web Authoring", "Bioinformatics", "Operating Systems", "Expert Systems"), 1, "<b>Bioinformatics</b> applies software design and information systems to analyze complex biological datasets, like genetic sequencing.")
    )
}
