package com.example

object Topic6Questions {
    val questions = listOf(
        Question(
            id = 601,
            topic = "Fundamentals of Programming",
            questionHtml = "What is an <b>algorithm</b> in computer programming?",
            options = listOf(
                "A physical chip designed to compile applications.",
                "A clear, step-by-step set of logical instructions used to solve a specific problem.",
                "A style layout sheet used to color website buttons.",
                "A storage database that holds user credentials."
            ),
            correctIndex = 1,
            explanationHtml = "An <b>algorithm</b> is a finite, step-by-step sequence of instructed logic used to solve a targeted math or computer science problem."
        ),
        Question(
            id = 602,
            topic = "Fundamentals of Programming",
            questionHtml = "Which graphical layout tool utilizes standardized geometric shapes connected by arrows to model algorithmic steps?",
            options = listOf(
                "Relational Database Schema",
                "Flowchart",
                "HTML webpage body tag",
                "Class hierarchy diagram"
            ),
            correctIndex = 1,
            explanationHtml = "A <b>Flowchart</b> is a visual diagram mapping out algorithmic sequences, with shapes (rectangles, diamonds) indicating tasks or branch options."
        ),
        Question(
            id = 603,
            topic = "Fundamentals of Programming",
            questionHtml = "In a flowchart, what logical step does a <b>diamond-shaped</b> box represent?",
            options = listOf(
                "The start or end of the program.",
                "A decision or branching condition (evaluate True or False).",
                "A standard computational step or mathematical assignment.",
                "An external input/output operation."
            ),
            correctIndex = 1,
            explanationHtml = "The <b>diamond</b> indicates a logical decision point. It evaluates a conditional test (like x > 5) and branches flow accordingly."
        ),
        Question(
            id = 604,
            topic = "Fundamentals of Programming",
            questionHtml = "In a flowchart, what operation does a <b>parallelogram-shaped</b> box represent?",
            options = listOf(
                "A standard processing operation.",
                "Input or Output (I/O) statements (e.g., read user input, print result).",
                "A decision branch.",
                "The terminal start/stop boundary."
            ),
            correctIndex = 1,
            explanationHtml = "A <b>parallelogram</b> represents input/output actions inside flowcharts, indicating reading values or rendering output strings."
        ),
        Question(
            id = 605,
            topic = "Fundamentals of Programming",
            questionHtml = "What is <b>Pseudocode</b>?",
            options = listOf(
                "An encrypted binary file format.",
                "An informal, high-level description of an algorithm written in plain English, designed for human reading.",
                "An active compiler that executes logical instructions.",
                "A security library used to protect files."
            ),
            correctIndex = 1,
            explanationHtml = "<b>Pseudocode</b> explains coding algorithms using simple English phrases instead of strict compiler syntax rules."
        ),
        Question(606, "Fundamentals of Programming", "What is the role of a <b>compiler</b> in programming?", listOf("Running database queries from server ports.", "Reading the entire high-level source code file at once and translating it into an executable machine code file.", "Styling web page navigation bars.", "Checking memory components for electrostatic charges."), 1, "A <b>compiler</b> processes the entire source code base, producing an independent static binary executable (e.g., .exe) ready for launch."),
        Question(607, "Fundamentals of Programming", "Compare compilers with interpreters. An <b>interpreter</b> operates by doing what?", listOf("Translating high-level source code line-by-line in real-time during execution.", "Organizing SQL columns into normalized forms.", "Formatting web pages down using cascading tags.", "Defragmenting hard disk sector layers."), 0, "Unlike compilers, an <b>interpreter</b> parses, translates, and executes code instruction-by-instruction, which assists dynamic debugging."),
        Question(608, "Fundamentals of Programming", "In programming variables, what does a **Boolean** data type store?", listOf("Floating decimal numbers.", "A single text character.", "One of two possible values: True or False.", "An array of text strings."), 2, "A **Boolean** data type holds logical flag variables that evaluate as either true or false."),
        Question(609, "Fundamentals of Programming", "What type of error prevents programs from executing or compiling altogether because of mismatched brackets, typos, or invalid keywords?", listOf("Runtime Error", "Syntax Error", "Logic Error", "Out-of-Memory Error"), 1, "<b>Syntax errors</b> are spelling or structure violations in code rules that fail compilation before running."),
        Question(610, "Fundamentals of Programming", "If a program compiles successfully and runs, but outputs incorrect mathematical values (e.g., calculating Average as Sum * Count instead of Sum / Count), what error exists?", listOf("Syntax Error", "Runtime Error", "Logic Error", "NullPointer Exception"), 2, "A <b>logic error</b> means code executes without crashing, but produces incorrect results because the underlying math or logic was programmed incorrectly."),
        Question(611, "Fundamentals of Programming", "What is a **Runtime Error**?", listOf("An error flagged by compilers during source build phases.", "An error that occurs while the program is actively running, often crashing it because of division-by-zero or missing files.", "A layout problem on mobile terminals.", "An unnormalized primary key in SQL."), 1, "A <b>Runtime Error</b> happens during execution, forcing program crashes on faulty operations, like dividing by a zero variable."),
        Question(612, "Fundamentals of Programming", "What is a **Variable** in programming?", listOf("A hardcoded value that can never be modified.", "A named memory space used to store and update data values during program execution.", "A code processor that converts files to HTML.", "An input flowchart symbol."), 1, "A <b>Variable</b> acts as a labeled container in memory, holding data that can change as logic runs."),
        Question(613, "Fundamentals of Programming", "Which data type is most appropriate for storing a whole number like 105 (no decimal points)?", listOf("Float / Double", "Integer (int)", "Char", "String"), 1, "The <b>Integer (int)</b> data type is used for whole numbers (positive, negative, or zero), without fractional parts."),
        Question(614, "Fundamentals of Programming", "Which data type is used for storing fractional numbers and decimals like 3.1415 or 85.50?", listOf("Integer", "Float / Double", "Boolean", "None"), 1, "<b>Float or Double</b> data types represent real numbers containing decimal points."),
        Question(615, "Fundamentals of Programming", "What variable structure holds an ordered list of multiple values of the exact same data type under a single identifier?", listOf("Simple Boolean", "Array", "Integer Pointer", "Null Constant"), 1, "An <b>Array</b> is a collection of elements of the same type stored in contiguous memory locations, accessed using an index (starting at 0)."),
        Question(616, "Fundamentals of Programming", "What index number retrieves the very first element of an array in almost all modern programming languages?", listOf("Index 1", "Index -1", "Index 0", "Index [First]"), 2, "Standard arrays are <b>zero-indexed</b>, meaning array[0] accesses the initial element."),
        Question(617, "Fundamentals of Programming", "What flow control structure allows code to branch and run different paths based on whether a condition is true or false?", listOf("While Loop", "Conditional Statement (if-then-else)", "Array assignment", "Pseudocode marker"), 1, "An <b>if-else conditional</b> tests an expression, routing code execution downward along the true path or alternative branch."),
        Question(618, "Fundamentals of Programming", "Which looping structure consistently executes a block of code a set number of times using an active counter variable?", listOf("if-else statement", "For Loop", "While Loop", "Switch Case"), 1, "A <b>For loop</b> is designed for definite loops, iterating over a specific range or collection with an incremental step."),
        Question(619, "Fundamentals of Programming", "Which looping structure continues to execute code repeatedly as long as a specified condition remains True, evaluate-testing the condition *before* running?", listOf("Do-While Loop", "While Loop", "For Loop", "If Statement"), 1, "A <b>While loop</b> evaluates its entry condition before running, meaning the code block may execute zero times if the condition is false initially."),
        Question(620, "Fundamentals of Programming", "How does a **Do-While** looping structure differ strictly from a **While** loop?", listOf("It never checks conditions.", "It compiles much faster.", "It guarantees that the code block is executed at least once before checking the condition.", "It only supports integer variables."), 2, "A <b>Do-While</b> loop tests the condition *after* running the code block, ensuring the code block runs at least once."),
        Question(621, "Fundamentals of Programming", "A loop that lacks an exit condition or possesses a condition that never evaluates to false, causing the program to run forever, is called a:", listOf("Continuous branch", "Infinite Loop", "Transitive loop", "Recursion exit"), 1, "An <b>Infinite Loop</b> occurs when loop termination logic is missing or broken, locking up CPU resources."),
        Question(622, "Fundamentals of Programming", "What is a **Function** or **Procedure** in coding?", listOf("The startup sequence of operating systems.", "A reusable block of code designed to perform a specific task, which can accept inputs and return outputs.", "An array sorting variable.", "A security algorithm."), 1, "A <b>Function</b> packages a block of code, allowing programmers to call it from different parts of the app, avoiding duplicate code."),
        Question(623, "Fundamentals of Programming", "What name is given to the input variables that are declared inside a function's definition?", listOf("Arguments", "Parameters", "Constants", "Return values"), 1, "<b>Parameters</b> are variables defined in the function signature. **Arguments** are the actual values passed when calling the function."),
        Question(624, "Fundamentals of Programming", "What programming concept involves a function calling itself directly or indirectly to solve a problem divided into simpler sub-cases?", listOf("Array indexing", "Recursion", "Iterative branching", "Static nesting"), 1, "<b>Recursion</b> is a programming technique where a function calls itself until a base exit condition is met, preventing infinite stack loops."),
        Question(625, "Fundamentals of Programming", "In Object-Oriented Programming (OOP), what is a **Class**?", listOf("A group of students checking exam questions.", "A blueprint or template that defines the properties (data) and behaviors (methods) of an object.", "A basic database management table.", "An active driver interface."), 1, "A <b>Class</b> defines properties and actions, acting as a structural blueprint from which individual objects are instantiated."),
        Question(626, "Fundamentals of Programming", "In OOP, what is an **Object**?", listOf("A specific instance of a Class containing real values.", "A programming syntax error.", "A flowchart connecting diamond shape.", "An operating system service."), 0, "An <b>Object</b> is an instance of a class that holds specific data and can invoke the methods defined by its class."),
        Question(627, "Fundamentals of Programming", "What does the concept of **Encapsulation** represent in Object-Oriented Programming?", listOf("Translating code across line levels in real-time.", "Grouping data and methods inside a single unit (class) while restricting direct outer access to keep internal states safe.", "Creating relational indexes between tables.", "Formatting code into XML structures."), 1, "<b>Encapsulation</b> hides internal object data, exposing access to properties only through safe public methods (getters/setters)."),
        Question(628, "Fundamentals of Programming", "In OOP, what concept allows a new class to acquire all the properties and methods of an existing parent class?", listOf("Encapsulation", "Inheritance", "Polymorphism", "Abstraction"), 1, "<b>Inheritance</b> promotes code reuse by allowing child classes to inherit fields and methods from a parent class."),
        Question(629, "Fundamentals of Programming", "What concept allows different classes to implement the same method in distinct ways (e.g., calling makeAnimalSound() on Dog makes Woof, while on Cat makes Meow)?", listOf("Inheritance", "Polymorphism", "Encapsulation", "Atomic parsing"), 1, "<b>Polymorphism</b> (many forms) allows objects of different classes to respond differently to the same method call."),
        Question(630, "Fundamentals of Programming", "What index is matched to the LAST item inside an array of size *N*?", listOf("N", "N - 1", "0", "N + 1"), 1, "Because arrays start indexing at 0, the N-th element is index **N - 1**."),
        Question(631, "Fundamentals of Programming", "Which operator is most commonly used to test if two values are equal in modern programming languages like Java, C++, or JavaScript?", listOf("=", "==", "!=", "&&"), 1, "While `=` is used for **variable assignment**, `==` (or `===`) tests for **equality**."),
        Question(632, "Fundamentals of Programming", "What is the result of evaluating the following logical expression: `(True AND False) OR True`?", listOf("False", "True", "Null", "Undetermined"), 1, "`(True AND False)` is False, and `False OR True` evaluates to **True**."),
        Question(633, "Fundamentals of Programming", "In programming, writing notes that explain what code does, which are ignored by compilers and interpreters altogether, is called:", listOf("Pseudocode planning", "Commenting", "Variable tracing", "System restore"), 1, "<b>Comments</b> (e.g., using `//` or `/* */`) are text logs written solely for humans to understand the logic, skipped during execution."),
        Question(634, "Fundamentals of Programming", "What is **source code**?", listOf("An executable binary file that computers run physically.", "The human-readable statements written in a programming language by a software developer.", "A list of database indexes.", "An IP configuration record."), 1, "<b>Source Code</b> is the text input defined by programmers using standard language syntax rules before compilation or interpretation."),
        Question(635, "Fundamentals of Programming", "A variable that is declared inside a function and can only be accessed within that function is called a:", listOf("Global Variable", "Local Variable", "Constant", "Static parameter"), 1, "A <b>Local Variable</b> has a scope limited to the block or function in which it is declared, disappearing once execution exits."),
        Question(636, "Fundamentals of Programming", "A variable declared outside of all functions, accessible from anywhere in the program, is a:", listOf("Local Variable", "Global Variable", "Static array", "Private field"), 1, "<b>Global variables</b> are defined at the top program level, and are accessible by any function in the source file."),
        Question(637, "Fundamentals of Programming", "What computer science concept describes tracking variables step-by-step to identify why recursive code is failing?", listOf("Database indexing", "Debugger tracing", "Antivirus cleaning", "Syntax validation"), 1, "A <b>Debugger</b> lets developers suspend execution, examine variable states line-by-line, and trace execution branches."),
        Question(638, "Fundamentals of Programming", "What does it mean to **declare** a variable?", listOf("Assigning an initial active value to it.", "Stating the variable's name and data type to the compiler, allocating memory space for use.", "Deleting the variable from RAM memory.", "Converting variables to HTML code."), 1, "<b>Declaration</b> defines a variable's name and type, reserving memory. **Initialization** assigns its first value."),
        Question(639, "Fundamentals of Programming", "What does it mean to **initialize** a variable?", listOf("Stating the name and data type.", "Assigning a starting physical value to a declared variable.", "Compiling the code into a binary file.", "Removing local scope checks."), 1, "<b>Initialization</b> is the first assignment of a value to a variable, which is recommended before reading it in code."),
        Question(640, "Fundamentals of Programming", "What variable modifier indicates a value that cannot be changed or reassigned after initialization?", listOf("Dynamic", "Constant (const / val)", "Global", "Public"), 1, "A <b>Constant</b> defines a read-only variable whose value is locked throughout execution (like Math.PI)."),
        Question(641, "Fundamentals of Programming", "What type of operator are `+`, `-`, `*`, `/`, and `%`?", listOf("Comparison Operators", "Arithmetic Operators", "Logical Operators", "Assignment Operators"), 1, "<b>Arithmetic operators</b> perform standard mathematical operations on numeric values."),
        Question(642, "Fundamentals of Programming", "What does the modulo operator (`%`) calculate?", listOf("The division answer rounded to integers.", "The remainder of an integer division.", "The multiplier constant of floating numbers.", "A logic check."), 1, "The **modulo operator (%)** returns the remainder of a division (e.g., `5 % 2` equals 1)."),
        Question(643, "Fundamentals of Programming", "What is the primary feature of low-level programming languages like Assembly?", listOf("They use simple English syntax similar to Python.", "They are close to binary machine code instructions and relate directly to processor registers.", "They do not compile into machine commands.", "They require relational database servers."), 1, "<b>Low-level languages</b> map closely to hardware registers, providing speed and control at the cost of complex programming."),
        Question(644, "Fundamentals of Programming", "Which of the following is commonly categorized as a high-level programming language?", listOf("Binary instructions", "Python / Kotlin / Java", "Machine code pulses", "POST beep standards"), 1, "<b>High-level languages</b> provide abstract, human-friendly syntax, relying on compilers/interpreters to output binary machine instructions."),
        Question(645, "Fundamentals of Programming", "What is **dry running** in programming algorithms?", listOf("Wipe-formatting the system hard drive.", "Manually tracing algorithmic steps paper-and-pencil-style with test values to verify correctness.", "Running programs with the cooling fan off.", "Executing SQL queries without databases."), 1, "<b>Dry running</b> is a diagnostic method where a programmer traces execution branches by hand to locate logical bugs."),
        Question(646, "Fundamentals of Programming", "In OOP, what term describes exposing only critical features of an object while hiding secondary implementation details?", listOf("Encapsulation", "Abstraction", "Inheritance", "Redundancy"), 1, "<b>Abstraction</b> isolates users and callers from complex back-end operations, exposing only simple interfaces (e.g., driveCar() hides piston combustion details)."),
        Question(647, "Fundamentals of Programming", "What occurs during **Divide and Conquer** algorithm designs?", listOf("An algorithm division that deletes files randomly.", "Breaking a complex problem into smaller sub-problems, solving them, and combining outcomes.", "Writing code in HTML formats only.", "Restricting user access blocks."), 1, "<b>Divide and Conquer</b> (e.g., Merge Sort) recursive models divide problems into sub-problems, resolve them, and synthesize the final output."),
        Question(648, "Fundamentals of Programming", "A data structure that follows the **Last-In, First-Out (LIFO)** protocol is a:", listOf("Queue", "Stack", "Relational row", "Pointer list"), 1, "A <b>Stack</b> is a LIFO structure; items are added (pushed) and removed (popped) from the same top end."),
        Question(649, "Fundamentals of Programming", "A data structure that follows the **First-In, First-Out (FIFO)** protocol is a:", listOf("Stack", "Queue", "B-Tree", "Relational schema"), 1, "A <b>Queue</b> is a FIFO structure; items are added at the tail and removed from the front (like a line in a store)."),
        Question(650, "Fundamentals of Programming", "In OOP, what block of code is automatically executed first when a new instance of a class (an object) is created?", listOf("Deconstructer", "Constructor", "Main static loop", "Global parameter definition"), 1, "A <b>Constructor</b> initializes the brand-new object instance, setting starting parameters and preparing resources.")
    )
}
