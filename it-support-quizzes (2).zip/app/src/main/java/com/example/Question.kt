package com.example

data class Question(
    val id: Int,
    val topic: String,
    val questionHtml: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanationHtml: String = ""
)
