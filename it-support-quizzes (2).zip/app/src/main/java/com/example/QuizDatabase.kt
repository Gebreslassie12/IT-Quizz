package com.example

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "topic_scores")
data class TopicScore(
    @PrimaryKey val topicName: String,
    val bestScore: Int,
    val completed: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface TopicScoreDao {
    @Query("SELECT * FROM topic_scores")
    fun getAllScores(): Flow<List<TopicScore>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScore(score: TopicScore)

    @Query("SELECT * FROM topic_scores WHERE topicName = :topic LIMIT 1")
    suspend fun getScoreForTopic(topic: String): TopicScore?
}

@Database(entities = [TopicScore::class], version = 1, exportSchema = false)
abstract class QuizDatabase : RoomDatabase() {
    abstract fun topicScoreDao(): TopicScoreDao

    companion object {
        @Volatile
        private var INSTANCE: QuizDatabase? = null

        fun getDatabase(context: Context): QuizDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QuizDatabase::class.java,
                    "quiz_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class QuizRepository(private val scoreDao: TopicScoreDao) {
    val allScores: Flow<List<TopicScore>> = scoreDao.getAllScores()

    suspend fun getScoreForTopic(topic: String): TopicScore? {
        return scoreDao.getScoreForTopic(topic)
    }

    suspend fun saveScore(topic: String, score: Int, completed: Boolean) {
        val existing = scoreDao.getScoreForTopic(topic)
        val bestScore = if (existing != null) {
            maxOf(existing.bestScore, score)
        } else {
            score
        }
        scoreDao.insertScore(
            TopicScore(
                topicName = topic,
                bestScore = bestScore,
                completed = completed || (existing?.completed ?: false),
                timestamp = System.currentTimeMillis()
            )
        )
    }
}
