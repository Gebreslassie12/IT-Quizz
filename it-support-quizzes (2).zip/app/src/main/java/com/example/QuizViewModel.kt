package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class Screen {
    object Welcome : Screen()
    object TopicSelect : Screen()
    data class Playing(val topic: String) : Screen()
    data class ScoreResult(val topic: String, val score: Int, val total: Int) : Screen()
    data class ReviewAnswers(val topic: String, val score: Int, val total: Int, val reviewItems: List<ReviewItem>) : Screen()
}

data class ReviewItem(
    val question: Question,
    val selectedIndex: Int?, // null if skipped
    val isCorrect: Boolean
)

class QuizViewModel(application: Application) : AndroidViewModel(application) {
    private val db = QuizDatabase.getDatabase(application)
    private val repository = QuizRepository(db.topicScoreDao())

    // UI screen flow state
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Welcome)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Database persistent score list state
    private val _topicScores = MutableStateFlow<List<TopicScore>>(emptyList())
    val topicScores: StateFlow<List<TopicScore>> = _topicScores.asStateFlow()

    // Game state inside current quiz
    private val _currentQuestions = MutableStateFlow<List<Question>>(emptyList())
    val currentQuestions: StateFlow<List<Question>> = _currentQuestions.asStateFlow()

    private val _currentQuestionIndex = MutableStateFlow(0)
    val currentQuestionIndex: StateFlow<Int> = _currentQuestionIndex.asStateFlow()

    private val _selectedOption = MutableStateFlow<Int?>(null)
    val selectedOption: StateFlow<Int?> = _selectedOption.asStateFlow()

    private val _isAnswerChecked = MutableStateFlow(false)
    val isAnswerChecked: StateFlow<Boolean> = _isAnswerChecked.asStateFlow()

    private val _score = MutableStateFlow(0)
    val score: StateFlow<Int> = _score.asStateFlow()

    // Save history of selected answers for review
    private val _sessionAnswers = MutableStateFlow<MutableList<ReviewItem>>(mutableListOf())
    val sessionAnswers: StateFlow<List<ReviewItem>> = _sessionAnswers.asStateFlow()

    init {
        // Collect topic scores from Room
        viewModelScope.launch {
            repository.allScores.collectLatest { scores ->
                _topicScores.value = scores
            }
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun startQuiz(topic: String) {
        val list = QuestionProvider.getQuestionsForTopic(topic).shuffled().take(50) // Take 50 randomized questions!
        // Wait, if the list is shorter than 50 we take what is available, but our files have exactly 50!
        _currentQuestions.value = list
        _currentQuestionIndex.value = 0
        _selectedOption.value = null
        _isAnswerChecked.value = false
        _score.value = 0
        _sessionAnswers.value = mutableListOf()
        navigateTo(Screen.Playing(topic))
    }

    fun selectOption(index: Int) {
        if (!_isAnswerChecked.value) { // Option selection locked once checked
            _selectedOption.value = index
        }
    }

    fun checkAnswer() {
        val currentIndex = _currentQuestionIndex.value
        val questionsList = _currentQuestions.value
        val selected = _selectedOption.value

        if (currentIndex < questionsList.size && selected != null && !_isAnswerChecked.value) {
            val question = questionsList[currentIndex]
            val correct = selected == question.correctIndex
            if (correct) {
                _score.value += 1
            }
            _isAnswerChecked.value = true

            // Add to session review
            val item = ReviewItem(
                question = question,
                selectedIndex = selected,
                isCorrect = correct
            )
            _sessionAnswers.value.add(item)
        }
    }

    fun nextQuestion(topic: String) {
        val currentIndex = _currentQuestionIndex.value
        val questionsList = _currentQuestions.value
        val total = questionsList.size

        // If user tapped next without checking (skipped or auto-saved):
        if (!_isAnswerChecked.value) {
            val question = questionsList[currentIndex]
            val selected = _selectedOption.value
            val correct = selected == question.correctIndex
            if (correct) {
                _score.value += 1
            }
            val item = ReviewItem(
                question = question,
                selectedIndex = selected,
                isCorrect = correct
            )
            _sessionAnswers.value.add(item)
        }

        if (currentIndex < total - 1) {
            _currentQuestionIndex.value += 1
            _selectedOption.value = null
            _isAnswerChecked.value = false
        } else {
            // Quiz completed!
            val finalScore = _score.value
            viewModelScope.launch {
                repository.saveScore(topic, finalScore, completed = true)
            }
            navigateTo(Screen.ScoreResult(topic, finalScore, total))
        }
    }

    fun resetToWelcome() {
        navigateTo(Screen.Welcome)
    }

    fun navigateToTopicSelect() {
        navigateTo(Screen.TopicSelect)
    }

    fun viewReview(topic: String, finalScore: Int, total: Int) {
        val reviewList = _sessionAnswers.value.toList()
        navigateTo(Screen.ReviewAnswers(topic, finalScore, total, reviewList))
    }
}
